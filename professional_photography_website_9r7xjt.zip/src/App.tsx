import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from './contexts/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'
import AdminRoute from './components/AdminRoute'
import Layout from './components/Layout'
import DashboardLayout from './components/DashboardLayout'
import AdminLayout from './components/AdminLayout'

// Public pages
import HomePage from './components/HomePage'
import GalleryPage from './pages/GalleryPage'
import ServicesPage from './pages/ServicesPage'
import PricingPage from './pages/PricingPage'
import AboutPage from './pages/AboutPage'
import ContactPage from './pages/ContactPage'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import NotFoundPage from './pages/NotFoundPage'

// Dashboard pages
import DashboardPage from './pages/dashboard/DashboardPage'
import AppointmentsPage from './pages/dashboard/AppointmentsPage'
import MyPhotosPage from './pages/dashboard/MyPhotosPage'
import BookingPage from './pages/dashboard/BookingPage'
import MessagesPage from './pages/dashboard/MessagesPage'
import ProfilePage from './pages/dashboard/ProfilePage'
import SettingsPage from './pages/dashboard/SettingsPage'

// Admin pages
import AdminDashboardPage from './pages/admin/AdminDashboardPage'
import PhotoManagementPage from './pages/admin/PhotoManagementPage'
import BookingManagementPage from './pages/admin/BookingManagementPage'

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="gallery" element={<GalleryPage />} />
            <Route path="services" element={<ServicesPage />} />
            <Route path="pricing" element={<PricingPage />} />
            <Route path="about" element={<AboutPage />} />
            <Route path="contact" element={<ContactPage />} />
            <Route path="login" element={<LoginPage />} />
            <Route path="register" element={<RegisterPage />} />
          </Route>
          
          {/* Dashboard routes */}
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }>
            <Route index element={<DashboardPage />} />
            <Route path="appointments" element={<AppointmentsPage />} />
            <Route path="photos" element={<MyPhotosPage />} />
            <Route path="booking" element={<BookingPage />} />
            <Route path="messages" element={<MessagesPage />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="settings" element={<SettingsPage />} />
          </Route>
          
          {/* Admin routes */}
          <Route path="/admin" element={
            <AdminRoute>
              <AdminLayout />
            </AdminRoute>
          }>
            <Route index element={<AdminDashboardPage />} />
            <Route path="photos" element={<PhotoManagementPage />} />
            <Route path="bookings" element={<BookingManagementPage />} />
          </Route>
          
          {/* Redirect /dashboard/photos to /dashboard/photos for backward compatibility */}
          <Route path="/dashboard/photos" element={<Navigate to="/dashboard/photos" replace />} />
          
          {/* 404 route */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Router>
      
      <Toaster position="top-right" />
    </AuthProvider>
  )
}

export default App
