import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Disclosure, Transition } from '@headlessui/react';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';
import { motion } from 'framer-motion';

const Header = () => {
  const { user, signOut } = useAuth();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'Gallery', href: '/gallery' },
    { name: 'Services', href: '/services' },
    { name: 'Pricing', href: '/pricing' },
    { name: 'About', href: '/about' },
    { name: 'Contact', href: '/contact' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <Disclosure
      as="nav"
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white shadow-md py-2'
          : 'bg-transparent py-4'
      }`}
    >
      {({ open }) => (
        <>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex">
                <div className="flex-shrink-0 flex items-center">
                  <Link to="/" className="flex items-center">
                    <span className={`font-display text-2xl font-bold ${scrolled ? 'text-primary-700' : 'text-white'}`}>
                      DXM
                    </span>
                    <span className={`ml-1 font-display text-2xl ${scrolled ? 'text-dark-800' : 'text-white'}`}>
                      Productions
                    </span>
                  </Link>
                </div>
              </div>
              
              {/* Desktop navigation */}
              <div className="hidden md:ml-6 md:flex md:items-center md:space-x-4">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`px-3 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                      isActive(item.href)
                        ? scrolled
                          ? 'text-primary-700 bg-primary-50'
                          : 'text-white bg-white bg-opacity-20'
                        : scrolled
                          ? 'text-dark-600 hover:text-primary-700 hover:bg-primary-50'
                          : 'text-white hover:bg-white hover:bg-opacity-10'
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
              
              <div className="hidden md:ml-6 md:flex md:items-center">
                {user ? (
                  <div className="flex items-center space-x-4">
                    <Link
                      to="/dashboard"
                      className={`px-4 py-2 text-sm font-medium rounded-md ${
                        scrolled
                          ? 'bg-primary-600 text-white hover:bg-primary-700'
                          : 'bg-white text-primary-700 hover:bg-gray-100'
                      } transition-colors duration-200`}
                    >
                      Dashboard
                    </Link>
                    <button
                      onClick={signOut}
                      className={`px-4 py-2 text-sm font-medium rounded-md ${
                        scrolled
                          ? 'bg-white text-dark-700 hover:bg-gray-100 border border-gray-300'
                          : 'bg-transparent text-white hover:bg-white hover:bg-opacity-10 border border-white'
                      } transition-colors duration-200`}
                    >
                      Sign Out
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center space-x-4">
                    <Link
                      to="/login"
                      className={`px-4 py-2 text-sm font-medium rounded-md ${
                        scrolled
                          ? 'text-primary-700 hover:text-primary-800'
                          : 'text-white hover:bg-white hover:bg-opacity-10'
                      } transition-colors duration-200`}
                    >
                      Sign In
                    </Link>
                    <Link
                      to="/register"
                      className={`px-4 py-2 text-sm font-medium rounded-md ${
                        scrolled
                          ? 'bg-primary-600 text-white hover:bg-primary-700'
                          : 'bg-white text-primary-700 hover:bg-gray-100'
                      } transition-colors duration-200`}
                    >
                      Sign Up
                    </Link>
                  </div>
                )}
              </div>
              
              {/* Mobile menu button */}
              <div className="flex items-center md:hidden">
                <Disclosure.Button className={`inline-flex items-center justify-center p-2 rounded-md ${
                  scrolled
                    ? 'text-dark-500 hover:text-dark-700 hover:bg-gray-100'
                    : 'text-white hover:text-white hover:bg-white hover:bg-opacity-10'
                } focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500`}>
                  <span className="sr-only">Open main menu</span>
                  {open ? (
                    <XMarkIcon className="block h-6 w-6" aria-hidden="true" />
                  ) : (
                    <Bars3Icon className="block h-6 w-6" aria-hidden="true" />
                  )}
                </Disclosure.Button>
              </div>
            </div>
          </div>

          {/* Mobile menu */}
          <Transition
            enter="transition duration-100 ease-out"
            enterFrom="transform scale-95 opacity-0"
            enterTo="transform scale-100 opacity-100"
            leave="transition duration-75 ease-out"
            leaveFrom="transform scale-100 opacity-100"
            leaveTo="transform scale-95 opacity-0"
          >
            <Disclosure.Panel className="md:hidden bg-white shadow-lg">
              <div className="px-2 pt-2 pb-3 space-y-1">
                {navigation.map((item) => (
                  <Disclosure.Button
                    key={item.name}
                    as={Link}
                    to={item.href}
                    className={`block px-3 py-2 rounded-md text-base font-medium ${
                      isActive(item.href)
                        ? 'bg-primary-50 text-primary-700'
                        : 'text-dark-600 hover:bg-gray-50 hover:text-primary-700'
                    }`}
                  >
                    {item.name}
                  </Disclosure.Button>
                ))}
              </div>
              <div className="pt-4 pb-3 border-t border-gray-200">
                {user ? (
                  <div className="px-2 space-y-1">
                    <Disclosure.Button
                      as={Link}
                      to="/dashboard"
                      className="block px-3 py-2 rounded-md text-base font-medium text-dark-600 hover:bg-gray-50 hover:text-primary-700"
                    >
                      Dashboard
                    </Disclosure.Button>
                    <Disclosure.Button
                      as="button"
                      onClick={signOut}
                      className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-dark-600 hover:bg-gray-50 hover:text-primary-700"
                    >
                      Sign Out
                    </Disclosure.Button>
                  </div>
                ) : (
                  <div className="px-2 space-y-1">
                    <Disclosure.Button
                      as={Link}
                      to="/login"
                      className="block px-3 py-2 rounded-md text-base font-medium text-dark-600 hover:bg-gray-50 hover:text-primary-700"
                    >
                      Sign In
                    </Disclosure.Button>
                    <Disclosure.Button
                      as={Link}
                      to="/register"
                      className="block px-3 py-2 rounded-md text-base font-medium text-dark-600 hover:bg-gray-50 hover:text-primary-700"
                    >
                      Sign Up
                    </Disclosure.Button>
                  </div>
                )}
              </div>
            </Disclosure.Panel>
          </Transition>
        </>
      )}
    </Disclosure>
  );
};

export default Header;
