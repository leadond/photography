import { motion } from 'framer-motion'

interface ServiceCardProps {
  title: string
  description: string
  imageUrl: string
  link: string
  index?: number
}

const ServiceCard = ({ title, description, imageUrl, link, index = 0 }: ServiceCardProps) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="card group"
    >
      <div className="relative h-72 overflow-hidden">
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/60 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-300"></div>
        
        <div className="absolute inset-0 flex flex-col justify-end p-6">
          <h3 className="text-2xl font-bold text-white group-hover:text-primary-300 transition-colors duration-300">{title}</h3>
          <div className="w-10 h-1 bg-primary-500 mt-2 mb-3 transition-all duration-300 group-hover:w-16"></div>
          <p className="text-gray-300 text-sm opacity-0 -translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">{description}</p>
        </div>
      </div>
      
      <div className="p-6 flex justify-between items-center">
        <p className="text-gray-600 font-medium">{title}</p>
        <a
          href={link}
          className="text-primary-600 font-medium hover:text-primary-700 flex items-center group/link"
        >
          Explore
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1 transition-transform duration-300 group-hover/link:translate-x-1" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </a>
      </div>
    </motion.div>
  )
}

export default ServiceCard
