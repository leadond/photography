import { useState } from 'react'
import { motion } from 'framer-motion'

interface CategoryFilterProps {
  categories: string[]
  activeCategory: string | undefined
  onCategoryChange: (category: string | undefined) => void
}

const CategoryFilter = ({ categories, activeCategory, onCategoryChange }: CategoryFilterProps) => {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null)

  return (
    <div className="mb-10">
      <div className="flex flex-wrap justify-center gap-2 md:gap-4">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={`px-4 py-2 rounded-full text-sm md:text-base font-medium transition-colors relative ${
            activeCategory === undefined
              ? 'bg-primary-600 text-white'
              : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
          }`}
          onClick={() => onCategoryChange(undefined)}
          onMouseEnter={() => setHoveredCategory('all')}
          onMouseLeave={() => setHoveredCategory(null)}
        >
          All Photos
          {hoveredCategory === 'all' && activeCategory !== undefined && (
            <motion.span
              layoutId="categoryHighlight"
              className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-500"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />
          )}
          {activeCategory === undefined && (
            <motion.span
              layoutId="categoryHighlight"
              className="absolute bottom-0 left-0 right-0 h-0.5 bg-white"
            />
          )}
        </motion.button>

        {categories.map((category) => (
          <motion.button
            key={category}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`px-4 py-2 rounded-full text-sm md:text-base font-medium transition-colors relative ${
              activeCategory === category
                ? 'bg-primary-600 text-white'
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
            onClick={() => onCategoryChange(category)}
            onMouseEnter={() => setHoveredCategory(category)}
            onMouseLeave={() => setHoveredCategory(null)}
          >
            {category}
            {hoveredCategory === category && activeCategory !== category && (
              <motion.span
                layoutId="categoryHighlight"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-500"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              />
            )}
            {activeCategory === category && (
              <motion.span
                layoutId="categoryHighlight"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-white"
              />
            )}
          </motion.button>
        ))}
      </div>
    </div>
  )
}

export default CategoryFilter
