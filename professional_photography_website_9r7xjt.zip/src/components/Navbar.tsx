import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Disclosure, Menu, Transition } from '@headlessui/react'
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline'
import { useAuth } from '../contexts/AuthContext'
import { motion } from 'framer-motion'

// Create a placeholder logo component since the image import is failing
const LogoPlaceholder = () => (
  <div className="h-8 w-auto flex items-center justify-center font-bold text-primary-600 text-xl">
    <span className="font-serif">DXM</span>
  </div>
)

function classNames(...classes: string[]) {
  return classes.filter(Boolean).join(' ')
}

export default function Navbar() {
  const { user, signOut } = useAuth()
  const location = useLocation()
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled)
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [scrolled])

  const navigation = [
    { name: 'Home', to: '/' },
    { name: 'Gallery', to: '/gallery' },
    { name: 'Pricing', to: '/pricing' },
    { name: 'Contact', to: '/contact' },
  ]

  const handleSignOut = async () => {
    await signOut()
  }

  const navbarClasses = classNames(
    'fixed w-full z-50 transition-all duration-300',
    scrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
  )

  const linkClasses = (isActive: boolean) => {
    return classNames(
      isActive
        ? 'text-primary-600 font-medium'
        : scrolled ? 'text-gray-700' : 'text-white',
      'inline-flex items-center px-1 pt-1 text-sm font-medium relative group transition-colors duration-300 hover:text-primary-500'
    )
  }

  const linkUnderlineClasses = (isActive: boolean) => {
    return classNames(
      'absolute bottom-0 left-0 w-0 h-0.5 bg-primary-500 group-hover:w-full transition-all duration-300',
      isActive ? 'w-full' : 'w-0'
    )
  }

  return (
    <Disclosure as="nav" className={navbarClasses}>
      {({ open }) => (
        <>
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex h-16 justify-between">
              <div className="flex">
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5 }}
                  className="flex flex-shrink-0 items-center"
                >
                  <Link to="/">
                    <LogoPlaceholder />
                  </Link>
                </motion.div>
                <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                  {navigation.map((item, index) => (
                    <motion.div
                      key={item.name}
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <Link
                        to={item.to}
                        className={linkClasses(location.pathname === item.to)}
                      >
                        {item.name}
                        <span className={linkUnderlineClasses(location.pathname === item.to)} />
                      </Link>
                    </motion.div>
                  ))}
                </div>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:items-center">
                {user ? (
                  <Menu as="div" className="relative ml-3">
                    <div>
                      <Menu.Button className="flex rounded-full bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-all duration-300 hover:ring-2 hover:ring-primary-400">
                        <span className="sr-only">Open user menu</span>
                        <div className="h-9 w-9 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center text-white font-semibold shadow-md">
                          {user.email?.charAt(0).toUpperCase()}
                        </div>
                      </Menu.Button>
                    </div>
                    <Transition
                      enter="transition ease-out duration-200"
                      enterFrom="transform opacity-0 scale-95"
                      enterTo="transform opacity-100 scale-100"
                      leave="transition ease-in duration-75"
                      leaveFrom="transform opacity-100 scale-100"
                      leaveTo="transform opacity-0 scale-95"
                    >
                      <Menu.Items className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                        <Menu.Item>
                          {({ active }) => (
                            <Link
                              to="/dashboard"
                              className={classNames(
                                active ? 'bg-gray-100' : '',
                                'block px-4 py-2 text-sm text-gray-700'
                              )}
                            >
                              Dashboard
                            </Link>
                          )}
                        </Menu.Item>
                        <Menu.Item>
                          {({ active }) => (
                            <button
                              onClick={handleSignOut}
                              className={classNames(
                                active ? 'bg-gray-100' : '',
                                'block w-full text-left px-4 py-2 text-sm text-gray-700'
                              )}
                            >
                              Sign out
                            </button>
                          )}
                        </Menu.Item>
                      </Menu.Items>
                    </Transition>
                  </Menu>
                ) : (
                  <div className="flex space-x-4">
                    <motion.div
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: 0.4 }}
                    >
                      <Link
                        to="/login"
                        className={`inline-flex items-center rounded-md border border-transparent px-4 py-2 text-sm font-medium transition-all duration-300 ${
                          scrolled 
                            ? 'bg-white text-primary-600 border-primary-600 hover:bg-primary-50' 
                            : 'bg-white/10 text-white backdrop-blur-sm hover:bg-white/20'
                        }`}
                      >
                        Log in
                      </Link>
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: 0.5 }}
                    >
                      <Link
                        to="/signup"
                        className="inline-flex items-center rounded-md border border-transparent bg-primary-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-primary-700 transition-all duration-300 hover:-translate-y-1"
                      >
                        Sign up
                      </Link>
                    </motion.div>
                  </div>
                )}
              </div>
              <div className="-mr-2 flex items-center sm:hidden">
                <Disclosure.Button className={`inline-flex items-center justify-center rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500 ${
                  scrolled ? 'text-gray-700 hover:bg-gray-100' : 'text-white hover:bg-white/10'
                }`}>
                  <span className="sr-only">Open main menu</span>
                  {open ? (
                    <XMarkIcon className="block h-6 w-6" aria-hidden="true" />
                  ) : (
                    <Bars3Icon className="block h-6 w-6" aria-hidden="true" />
                  )}
                </Disclosure.Button>
              </div>
            </div>
          </div>

          <Disclosure.Panel className="sm:hidden bg-white shadow-lg">
            <div className="space-y-1 pb-3 pt-2">
              {navigation.map((item) => (
                <Disclosure.Button
                  key={item.name}
                  as={Link}
                  to={item.to}
                  className={classNames(
                    location.pathname === item.to
                      ? 'bg-primary-50 border-primary-500 text-primary-700'
                      : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700',
                    'block border-l-4 py-2 pl-3 pr-4 text-base font-medium transition-colors duration-200'
                  )}
                >
                  {item.name}
                </Disclosure.Button>
              ))}
            </div>
            {/* Wrap the adjacent JSX elements in a fragment */}
            <>
              <div className="border-t border-gray-200 pb-3 pt-4">
                {user ? (
                  <div className="flex items-center px-4">
                    <div className="flex-shrink-0">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center text-white font-semibold shadow-md">
                        {user.email?.charAt(0).toUpperCase()}
                      </div>
                    </div>
                    <div className="ml-3">
                      <div className="text-base font-medium text-gray-800">
                        {user.email}
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
              <div className="mt-3 space-y-1 border-t border-gray-200 pt-4">
                {user ? (
                  <>
                    <Link
                      to="/dashboard"
                      className="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100 transition-colors duration-200"
                    >
                      Dashboard
                    </Link>
                    <button
                      onClick={handleSignOut}
                      className="block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100 transition-colors duration-200"
                    >
                      Sign out
                    </button>
                  </>
                ) : (
                  <div className="px-4 py-3 flex flex-col space-y-2">
                    <Link
                      to="/login"
                      className="block w-full text-center px-4 py-2 rounded-md text-base font-medium text-primary-600 border border-primary-600 hover:bg-primary-50 transition-colors duration-200"
                    >
                      Log in
                    </Link>
                    <Link
                      to="/signup"
                      className="block w-full text-center px-4 py-2 rounded-md text-base font-medium text-white bg-primary-600 hover:bg-primary-700 transition-colors duration-200"
                    >
                      Sign up
                    </Link>
                  </div>
                )}
              </div>
            </>
          </Disclosure.Panel>
        </>
      )}
    </Disclosure>
  )
}
