import { useState, useEffect, useRef } from 'react'
import { motion } from 'framer-motion'

interface Photo {
  id: string
  url: string
  title: string
  category: string
  aspectRatio?: 'portrait' | 'landscape' | 'square' | 'wide'
}

interface GalleryGridProps {
  photos: Photo[]
  category?: string
}

const GalleryGrid = ({ photos, category }: GalleryGridProps) => {
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null)
  const [filteredPhotos, setFilteredPhotos] = useState<Photo[]>([])
  const gridRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Filter photos by category if provided
    const filtered = category ? photos.filter(photo => photo.category === category) : photos
    
    // Assign random aspect ratios if not provided
    const processedPhotos = filtered.map(photo => {
      if (!photo.aspectRatio) {
        const ratios = ['portrait', 'landscape', 'square', 'wide'] as const
        const randomIndex = Math.floor(Math.random() * ratios.length)
        return { ...photo, aspectRatio: ratios[randomIndex] }
      }
      return photo
    })
    
    setFilteredPhotos(processedPhotos)
  }, [photos, category])

  const openPhotoModal = (photo: Photo) => {
    setSelectedPhoto(photo)
    document.body.style.overflow = 'hidden'
  }

  const closePhotoModal = () => {
    setSelectedPhoto(null)
    document.body.style.overflow = 'auto'
  }

  const getItemClass = (aspectRatio?: string) => {
    switch (aspectRatio) {
      case 'portrait':
        return 'photo-grid-item tall'
      case 'landscape':
        return 'photo-grid-item wide'
      case 'wide':
        return 'photo-grid-item wide'
      case 'square':
      default:
        return 'photo-grid-item'
    }
  }

  return (
    <>
      <div ref={gridRef} className="photo-grid">
        {filteredPhotos.map((photo) => (
          <motion.div
            key={photo.id}
            layoutId={`photo-${photo.id}`}
            className={getItemClass(photo.aspectRatio)}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            onClick={() => openPhotoModal(photo)}
          >
            <div className="relative h-full w-full overflow-hidden group cursor-pointer">
              <img
                src={photo.url}
                alt={photo.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                <div>
                  <h3 className="text-white font-medium text-lg">{photo.title}</h3>
                  <p className="text-gray-300 text-sm">{photo.category}</p>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Photo Modal */}
      {selectedPhoto && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90"
          onClick={closePhotoModal}
        >
          <motion.div
            layoutId={`photo-${selectedPhoto.id}`}
            className="relative max-w-5xl max-h-[90vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={selectedPhoto.url}
              alt={selectedPhoto.title}
              className="w-full h-full object-contain"
            />
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
              <h2 className="text-white text-xl font-medium">{selectedPhoto.title}</h2>
              <p className="text-gray-300">{selectedPhoto.category}</p>
            </div>
            <button
              className="absolute top-4 right-4 text-white bg-black/50 rounded-full p-2 hover:bg-black/70 transition-colors"
              onClick={closePhotoModal}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </motion.div>
        </motion.div>
      )}
    </>
  )
}

export default GalleryGrid
