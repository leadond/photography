import { Link } from 'react-router-dom'

const AboutPage = () => {
  const team = [
    {
      name: 'Alex Morgan',
      role: 'Lead Photographer',
      bio: 'With over 15 years of experience, Alex specializes in portrait and event photography. Their work has been featured in several national publications.',
      imageUrl: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    },
    {
      name: 'Jamie Wilson',
      role: 'Portrait Specialist',
      bio: 'Jamie has a unique talent for capturing the personality and essence of individuals in their portraits, creating images that truly reflect their subjects.',
      imageUrl: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    },
    {
      name: 'Taylor Reed',
      role: 'Event Photographer',
      bio: 'Taylor excels at documenting events with an unobtrusive approach, ensuring all the important moments are captured without disrupting the flow.',
      imageUrl: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    }
  ]

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gray-900 py-24 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0">
          <img
            className="w-full h-full object-cover"
            src="https://images.pexels.com/photos/3062541/pexels-photo-3062541.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
            alt="Photography studio"
          />
          <div className="absolute inset-0 bg-gray-900 opacity-70"></div>
        </div>
        <div className="relative max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl font-serif">
              About Luminous Photography
            </h1>
            <p className="mt-6 text-xl text-gray-300 max-w-3xl mx-auto">
              We're passionate about capturing life's most precious moments through the art of photography.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 font-serif">Our Story</h2>
              <div className="mt-6 text-lg text-gray-600 space-y-4">
                <p>
                  Founded in 2010, Luminous Photography began with a simple mission: to capture life's most meaningful moments with artistry and authenticity.
                </p>
                <p>
                  What started as a small studio has grown into a team of passionate photographers dedicated to providing exceptional photography services for all of life's important milestones.
                </p>
                <p>
                  Over the years, we've had the privilege of documenting thousands of special moments—from graduations and family portraits to corporate events and professional headshots. Each photo tells a unique story, and we're honored to be the ones capturing these memories for our clients.
                </p>
                <p>
                  Our approach combines technical expertise with a genuine connection to our clients. We believe that the best photos come from understanding the people we're photographing and creating an environment where they feel comfortable and authentic.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/3584996/pexels-photo-3584996.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Photographer in action"
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary-500 rounded-lg hidden md:block"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-serif">Our Values</h2>
            <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
              These core principles guide everything we do at Luminous Photography.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Passion</h3>
              <p className="text-gray-600">
                We're genuinely passionate about photography and approach each session with enthusiasm and creativity. This passion drives us to continuously improve our craft and deliver exceptional results.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Quality</h3>
              <p className="text-gray-600">
                We're committed to delivering the highest quality in everything we do—from the equipment we use to the final edited images. We never compromise on quality and always strive for excellence.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Connection</h3>
              <p className="text-gray-600">
                We believe that the best photos come from genuine connections. We take the time to understand our clients' vision and create a comfortable environment where authentic moments can be captured.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-serif">Meet Our Team</h2>
            <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
              Our talented photographers bring years of experience and a passion for capturing life's special moments.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-white rounded-lg overflow-hidden shadow-md">
                <img
                  src={member.imageUrl}
                  alt={member.name}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900">{member.name}</h3>
                  <p className="text-primary-600 font-medium">{member.role}</p>
                  <p className="mt-4 text-gray-600">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Process */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-serif">Our Process</h2>
            <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
              We've refined our approach to ensure a seamless experience from booking to delivery.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="relative">
              <div className="absolute top-0 left-1/2 -ml-px h-full w-0.5 bg-gray-200 hidden md:block"></div>
              <div className="relative flex items-start md:flex-col">
                <div className="h-12 w-12 rounded-full bg-primary-600 flex items-center justify-center text-white font-bold text-xl z-10">
                  1
                </div>
                <div className="ml-4 md:ml-0 md:mt-4">
                  <h3 className="text-xl font-bold text-gray-900">Consultation</h3>
                  <p className="mt-2 text-gray-600">
                    We start with a detailed consultation to understand your vision, preferences, and specific needs for your photography session.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute top-0 left-1/2 -ml-px h-full w-0.5 bg-gray-200 hidden md:block"></div>
              <div className="relative flex items-start md:flex-col">
                <div className="h-12 w-12 rounded-full bg-primary-600 flex items-center justify-center text-white font-bold text-xl z-10">
                  2
                </div>
                <div className="ml-4 md:ml-0 md:mt-4">
                  <h3 className="text-xl font-bold text-gray-900">Planning</h3>
                  <p className="mt-2 text-gray-600">
                    We carefully plan every aspect of your session, from location and lighting to poses and props, ensuring everything is perfect.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute top-0 left-1/2 -ml-px h-full w-0.5 bg-gray-200 hidden md:block"></div>
              <div className="relative flex items-start md:flex-col">
                <div className="h-12 w-12 rounded-full bg-primary-600 flex items-center justify-center text-white font-bold text-xl z-10">
                  3
                </div>
                <div className="ml-4 md:ml-0 md:mt-4">
                  <h3 className="text-xl font-bold text-gray-900">Photoshoot</h3>
                  <p className="mt-2 text-gray-600">
                    During the session, we create a comfortable environment where you can be yourself, allowing us to capture authentic moments.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="relative flex items-start md:flex-col">
                <div className="h-12 w-12 rounded-full bg-primary-600 flex items-center justify-center text-white font-bold text-xl z-10">
                  4
                </div>
                <div className="ml-4 md:ml-0 md:mt-4">
                  <h3 className="text-xl font-bold text-gray-900">Delivery</h3>
                  <p className="mt-2 text-gray-600">
                    After careful editing and refinement, we deliver your final images through our online gallery, where you can view, download, and share them.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-primary-700">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white font-serif">Ready to Work With Us?</h2>
          <p className="mt-4 text-xl text-primary-100 max-w-3xl mx-auto">
            Let's create beautiful memories together. Book a session or contact us to learn more about our services.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/pricing" className="btn bg-white text-primary-700 hover:bg-gray-100 text-base px-8 py-3">
              View Pricing
            </Link>
            <Link to="/contact" className="btn bg-primary-600 text-white border border-primary-500 hover:bg-primary-800 text-base px-8 py-3">
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default AboutPage
