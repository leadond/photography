import { MapPinIcon, PhoneIcon, ClockIcon } from '@heroicons/react/24/outline'
import ContactForm from '../components/ContactForm'

// Create a simple envelope icon component
const EnvelopeIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-6 w-6 text-primary-600">
    <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
  </svg>
)

const ContactPage = () => {
  const contactInfo = [
    {
      icon: <MapPinIcon className="h-6 w-6 text-primary-600" />,
      title: 'Visit our studio',
      content: '123 Photography Lane, Suite 101, New York, NY 10001',
      link: 'https://maps.google.com/?q=123+Photography+Lane+New+York+NY+10001',
      linkText: 'Get directions'
    },
    {
      icon: <PhoneIcon className="h-6 w-6 text-primary-600" />,
      title: 'Call us',
      content: '(555) 123-4567',
      link: 'tel:+15551234567',
      linkText: 'Call now'
    },
    {
      icon: <EnvelopeIcon />,
      title: 'Email us',
      content: 'derrick@dxmproductions.com',
      link: 'mailto:derrick@dxmproductions.com',
      linkText: 'Send email'
    },
    {
      icon: <ClockIcon className="h-6 w-6 text-primary-600" />,
      title: 'Business hours',
      content: 'Monday-Friday: 9am-6pm, Saturday: 10am-4pm, Sunday: Closed',
      link: null,
      linkText: null
    }
  ]

  const faqs = [
    {
      question: 'How do I book a photography session?',
      answer: 'You can book a session by creating an account, selecting your preferred package, and choosing an available date and time. Alternatively, you can contact us directly via phone or email to schedule your session.'
    },
    {
      question: 'What should I wear to my photo session?',
      answer: 'We recommend wearing solid colors and avoiding busy patterns. For family or group photos, coordinate your outfits without matching exactly. We\'ll provide a detailed preparation guide after booking.'
    },
    {
      question: 'How long until I receive my photos?',
      answer: 'Standard delivery time is 2-3 weeks for portrait sessions and 3-4 weeks for events. Rush delivery is available for an additional fee, which reduces delivery time to 48-72 hours.'
    },
    {
      question: 'Do you offer outdoor photography sessions?',
      answer: 'Yes! We offer both studio and outdoor photography sessions. We have several recommended outdoor locations, or we can shoot at a location of your choice within our service area.'
    }
  ]

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold font-serif mb-6">Contact Us</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Have questions or ready to book your photography session? We're here to help you capture your special moments.
          </p>
        </div>
      </section>
      
      {/* Contact Information */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {contactInfo.map((item, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="flex items-center justify-center w-12 h-12 bg-primary-100 rounded-full mb-4">
                  {item.icon}
                </div>
                <h3 className="text-lg font-bold mb-2">{item.title}</h3>
                <p className="text-gray-600 mb-4">{item.content}</p>
                {item.link && (
                  <a 
                    href={item.link} 
                    className="text-primary-600 hover:text-primary-800 font-medium flex items-center"
                    target={item.link.startsWith('http') ? '_blank' : undefined}
                    rel={item.link.startsWith('http') ? 'noopener noreferrer' : undefined}
                  >
                    {item.linkText}
                    <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                  </a>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Contact Form and Map */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold font-serif mb-6">Send Us a Message</h2>
              <p className="text-gray-600 mb-8">
                Fill out the form below and we'll get back to you as soon as possible. We're looking forward to hearing from you!
              </p>
              <ContactForm />
            </div>
            
            <div>
              <h2 className="text-3xl font-bold font-serif mb-6">Our Location</h2>
              <p className="text-gray-600 mb-8">
                Visit our studio in the heart of New York City. We're conveniently located near public transportation and have parking available.
              </p>
              <div className="h-96 bg-gray-200 rounded-lg overflow-hidden shadow-md">
                {/* Replace with actual Google Maps embed */}
                <div className="w-full h-full flex items-center justify-center bg-gray-300">
                  <p className="text-gray-600">Map Loading...</p>
                  {/* In a real implementation, you would add a Google Maps iframe here */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold font-serif mb-4">Frequently Asked Questions</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Find quick answers to common questions about our photography services.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold mb-3">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <p className="text-lg text-gray-600 mb-4">
              Have more questions? We're happy to help!
            </p>
            <a href="tel:+15551234567" className="btn btn-primary">
              Call Us Today
            </a>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="bg-primary-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold font-serif mb-6">Ready to Book Your Session?</h2>
          <p className="text-xl text-primary-100 mb-8 max-w-3xl mx-auto">
            Let DXM Productions help you capture your special moments with our professional photography services.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href="/pricing" className="btn bg-white text-primary-600 hover:bg-gray-100">
              View Pricing
            </a>
            <a href="/dashboard/book" className="btn btn-outline-white">
              Book Now
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}

export default ContactPage
