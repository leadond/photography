import { Link } from 'react-router-dom'
import { CheckIcon } from '@heroicons/react/24/outline'
import { useAuth } from '../contexts/AuthContext'

const PricingPage = () => {
  const { user } = useAuth()
  
  const packages = [
    {
      id: 'graduation',
      name: 'Graduation',
      price: 299,
      description: 'Capture your academic achievement with professional graduation photos.',
      features: [
        '1-hour photo session',
        'Up to 3 outfit changes',
        '20 digital photos',
        'Online gallery',
        'Print release',
        '5 professional prints (8x10)'
      ],
      popular: false
    },
    {
      id: 'family',
      name: 'Family Portrait',
      price: 349,
      description: 'Preserve precious family moments with beautiful portrait photography.',
      features: [
        '1.5-hour photo session',
        'Up to 2 locations',
        '30 digital photos',
        'Online gallery',
        'Print release',
        '1 canvas print (16x20)',
        '10 professional prints (various sizes)'
      ],
      popular: true
    },
    {
      id: 'corporate',
      name: 'Corporate Event',
      price: 599,
      description: 'Professional photography for your corporate events and conferences.',
      features: [
        '4-hour event coverage',
        'Multiple photographers',
        '100+ digital photos',
        'Online gallery',
        'Commercial usage rights',
        'Quick turnaround (48 hours)',
        'Professional editing'
      ],
      popular: false
    },
    {
      id: 'headshot',
      name: 'Professional Headshot',
      price: 199,
      description: 'Stand out with professional headshots for your business profile.',
      features: [
        '30-minute photo session',
        '2 outfit changes',
        '10 digital photos',
        'Online gallery',
        'Print release',
        'LinkedIn optimization',
        'Professional retouching'
      ],
      popular: false
    }
  ]

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold font-serif mb-6">Photography Packages & Pricing</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Choose from our range of professional photography packages designed to meet your needs.
          </p>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {packages.map((pkg) => (
              <div 
                key={pkg.id}
                className={`bg-white rounded-lg shadow-lg overflow-hidden border ${
                  pkg.popular ? 'border-primary-500' : 'border-gray-200'
                }`}
              >
                {pkg.popular && (
                  <div className="bg-primary-500 text-white text-center py-2 font-medium">
                    Most Popular
                  </div>
                )}
                <div className="p-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <div className="flex items-baseline mb-4">
                    <span className="text-3xl font-bold text-gray-900">${pkg.price}</span>
                    <span className="ml-1 text-gray-500">per session</span>
                  </div>
                  <p className="text-gray-600 mb-6">{pkg.description}</p>
                  
                  <ul className="space-y-3 mb-6">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckIcon className="flex-shrink-0 h-5 w-5 text-green-500 mt-0.5" />
                        <span className="ml-3 text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Link
                    to={user ? "/dashboard/booking" : "/login?redirect=/dashboard/booking"}
                    className={`block w-full text-center py-3 px-4 rounded-md font-medium ${
                      pkg.popular
                        ? 'bg-primary-600 text-white hover:bg-primary-700'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                    }`}
                  >
                    {user ? 'Book Now' : 'Sign In to Book'}
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Information */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold font-serif mb-6">Frequently Asked Questions</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-bold mb-2">How do I book a session?</h3>
                  <p className="text-gray-600">
                    You can book a session by creating an account, selecting your preferred package, and choosing an available date and time through our online booking system.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-xl font-bold mb-2">What is your cancellation policy?</h3>
                  <p className="text-gray-600">
                    We require 48 hours notice for cancellations. Cancellations made with less than 48 hours notice may be subject to a cancellation fee.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-xl font-bold mb-2">How long until I receive my photos?</h3>
                  <p className="text-gray-600">
                    For most sessions, you'll receive your edited photos within 7-10 business days. Corporate events have a quicker turnaround of 48 hours.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-xl font-bold mb-2">Can I purchase additional prints?</h3>
                  <p className="text-gray-600">
                    Yes, additional prints can be ordered through your online gallery. We offer a variety of sizes and finishes to choose from.
                  </p>
                </div>
              </div>
            </div>
            
            <div>
              <h2 className="text-3xl font-bold font-serif mb-6">Custom Packages</h2>
              <p className="text-lg text-gray-600 mb-6">
                Need something specific that's not covered by our standard packages? We offer custom photography packages tailored to your unique needs.
              </p>
              
              <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                <h3 className="text-xl font-bold mb-4">Custom Package Options</h3>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <CheckIcon className="flex-shrink-0 h-5 w-5 text-green-500 mt-0.5" />
                    <span className="ml-3 text-gray-600">Wedding photography</span>
                  </li>
                  <li className="flex items-start">
                    <CheckIcon className="flex-shrink-0 h-5 w-5 text-green-500 mt-0.5" />
                    <span className="ml-3 text-gray-600">Extended event coverage</span>
                  </li>
                  <li className="flex items-start">
                    <CheckIcon className="flex-shrink-0 h-5 w-5 text-green-500 mt-0.5" />
                    <span className="ml-3 text-gray-600">Product photography</span>
                  </li>
                  <li className="flex items-start">
                    <CheckIcon className="flex-shrink-0 h-5 w-5 text-green-500 mt-0.5" />
                    <span className="ml-3 text-gray-600">Real estate photography</span>
                  </li>
                </ul>
                
                <Link
                  to="/contact"
                  className="block w-full text-center py-3 px-4 rounded-md font-medium bg-primary-600 text-white hover:bg-primary-700"
                >
                  Contact for Custom Quote
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold font-serif mb-6">Ready to Book Your Photography Session?</h2>
          <p className="text-xl text-primary-100 mb-8 max-w-3xl mx-auto">
            Create an account or sign in to book your preferred photography package today.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            {user ? (
              <Link to="/dashboard/booking" className="btn bg-white text-primary-600 hover:bg-gray-100">
                Book Now
              </Link>
            ) : (
              <>
                <Link to="/signup" className="btn bg-white text-primary-600 hover:bg-gray-100">
                  Sign Up
                </Link>
                <Link to="/login" className="btn btn-outline-white">
                  Log In
                </Link>
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  )
}

export default PricingPage
