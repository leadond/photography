import { Link } from 'react-router-dom'
import Hero from '../components/Hero'
import ServiceCard from '../components/ServiceCard'
import TestimonialCard from '../components/TestimonialCard'

const HomePage = () => {
  const services = [
    {
      title: 'Graduation Photos',
      description: 'Commemorate your academic achievements with professional graduation photography that captures your pride and accomplishment.',
      imageUrl: 'https://images.pexels.com/photos/267885/pexels-photo-267885.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      link: '/pricing'
    },
    {
      title: 'Family Portraits',
      description: 'Create timeless family portraits that capture the unique bond and personality of your family in a comfortable, relaxed setting.',
      imageUrl: 'https://images.pexels.com/photos/1974521/pexels-photo-1974521.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      link: '/pricing'
    },
    {
      title: 'Corporate Events',
      description: 'Professional event photography for corporate gatherings, conferences, and team-building activities that showcase your company culture.',
      imageUrl: 'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      link: '/pricing'
    },
    {
      title: 'Professional Headshots',
      description: 'Elevate your professional image with high-quality headshots that make a strong first impression for your business or career.',
      imageUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      link: '/pricing'
    }
  ]

  const testimonials = [
    {
      quote: "Working with Luminous Photography was an absolute pleasure. They captured our family's personality perfectly, and the photos exceeded our expectations!",
      author: "Sarah Johnson",
      role: "Family Portrait Client",
      imageUrl: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      quote: "The graduation photos were stunning! They really captured the essence of this important milestone in my life. I'll cherish these memories forever.",
      author: "Michael Chen",
      role: "Graduation Client",
      imageUrl: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      quote: "Our corporate event was documented beautifully. The team was professional, unobtrusive, and delivered high-quality photos that perfectly represented our brand.",
      author: "Emily Rodriguez",
      role: "Marketing Director",
      imageUrl: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ]

  return (
    <div>
      <Hero />
      
      {/* Services Section */}
      <section className="section bg-gray-50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-serif sm:text-4xl">Our Photography Services</h2>
            <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
              We offer a wide range of professional photography services to capture your special moments.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <ServiceCard
                key={index}
                title={service.title}
                description={service.description}
                imageUrl={service.imageUrl}
                link={service.link}
              />
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <Link to="/pricing" className="btn btn-primary">
              View All Services
            </Link>
          </div>
        </div>
      </section>
      
      {/* About Section */}
      <section className="section bg-white">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 font-serif sm:text-4xl">Capturing Your Perfect Moments</h2>
              <p className="mt-4 text-lg text-gray-600">
                At Luminous Photography, we believe that every moment tells a story. Our passion is capturing those stories through the art of photography, creating timeless images that you'll treasure for generations.
              </p>
              <p className="mt-4 text-lg text-gray-600">
                With over 10 years of experience, our team of professional photographers specializes in a wide range of photography services, from graduation photos and family portraits to corporate events and professional headshots.
              </p>
              <div className="mt-8">
                <Link to="/about" className="btn btn-primary">
                  Learn More About Us
                </Link>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/3584996/pexels-photo-3584996.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Photographer in action"
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-primary-500 rounded-lg hidden md:block"></div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Gallery Preview */}
      <section className="section bg-gray-50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-serif sm:text-4xl">Our Recent Work</h2>
            <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
              Browse through our portfolio to see examples of our photography across different categories.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="relative overflow-hidden rounded-lg shadow-md group h-64 md:h-80">
              <img
                src="https://images.pexels.com/photos/1468379/pexels-photo-1468379.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Graduation photography"
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-60"></div>
              <div className="absolute bottom-0 left-0 p-6">
                <h3 className="text-xl font-bold text-white">Graduation</h3>
                <p className="text-gray-300">Celebrating academic achievements</p>
              </div>
            </div>
            
            <div className="relative overflow-hidden rounded-lg shadow-md group h-64 md:h-80">
              <img
                src="https://images.pexels.com/photos/3933923/pexels-photo-3933923.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Family portrait"
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-60"></div>
              <div className="absolute bottom-0 left-0 p-6">
                <h3 className="text-xl font-bold text-white">Family</h3>
                <p className="text-gray-300">Capturing precious moments</p>
              </div>
            </div>
            
            <div className="relative overflow-hidden rounded-lg shadow-md group h-64 md:h-80">
              <img
                src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Corporate event"
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-60"></div>
              <div className="absolute bottom-0 left-0 p-6">
                <h3 className="text-xl font-bold text-white">Corporate</h3>
                <p className="text-gray-300">Professional event coverage</p>
              </div>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <Link to="/gallery" className="btn btn-primary">
              View Full Gallery
            </Link>
          </div>
        </div>
      </section>
      
      {/* Testimonials */}
      <section className="section bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 font-serif sm:text-4xl">What Our Clients Say</h2>
            <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
              Don't just take our word for it. Here's what our clients have to say about their experience with us.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <TestimonialCard
                key={index}
                quote={testimonial.quote}
                author={testimonial.author}
                role={testimonial.role}
                imageUrl={testimonial.imageUrl}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="section bg-primary-700">
        <div className="container">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white font-serif sm:text-4xl">Ready to Capture Your Special Moments?</h2>
            <p className="mt-4 text-xl text-primary-100 max-w-3xl mx-auto">
              Book a photography session today and let us help you create memories that will last a lifetime.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/pricing" className="btn bg-white text-primary-700 hover:bg-gray-100 text-base px-8 py-3">
                View Pricing
              </Link>
              <Link to="/contact" className="btn bg-primary-600 text-white border border-primary-500 hover:bg-primary-800 text-base px-8 py-3">
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage
