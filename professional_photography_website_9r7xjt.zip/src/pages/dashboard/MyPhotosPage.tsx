import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
import { 
  ArrowDownTrayIcon, 
  XMarkIcon, 
  ChevronLeftIcon, 
  ChevronRightIcon,
  MagnifyingGlassIcon
} from '@heroicons/react/24/outline'

interface Photo {
  id: string
  url: string
  thumbnail_url: string
  title: string
  description: string
  created_at: string
  appointment_id: string
}

interface Appointment {
  id: string
  date: string
  package: {
    name: string
  }
}

interface PackageData {
  name: string | null
}

interface AppointmentData {
  id: string
  date: string
  package: PackageData | null
}

const MyPhotosPage = () => {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [selectedAppointment, setSelectedAppointment] = useState<string | null>(null)
  const [appointmentPhotos, setAppointmentPhotos] = useState<Photo[]>([])
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null)
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0)
  const [searchQuery, setSearchQuery] = useState('')
  const [filteredPhotos, setFilteredPhotos] = useState<Photo[]>([])
  
  useEffect(() => {
    const fetchAppointments = async () => {
      if (!user) return
      
      try {
        const { data, error } = await supabase
          .from('appointments')
          .select(`
            id,
            date,
            package:packages(name)
          `)
          .eq('user_id', user.id)
          .eq('status', 'completed')
          .order('date', { ascending: false })
        
        if (error) throw error
        
        if (data && data.length > 0) {
          // Convert the data to match our Appointment interface
          const formattedAppointments: Appointment[] = data.map((item: AppointmentData) => ({
            id: item.id,
            date: item.date,
            package: {
              name: item.package?.name || 'Unknown'
            }
          }))
          
          setAppointments(formattedAppointments)
          setSelectedAppointment(formattedAppointments[0].id)
        }
      } catch (error) {
        console.error('Error fetching appointments:', error)
        toast.error('Failed to load your appointments')
      } finally {
        setLoading(false)
      }
    }
    
    fetchAppointments()
  }, [user])
  
  useEffect(() => {
    const fetchPhotos = async () => {
      if (!selectedAppointment) return
      
      try {
        setLoading(true)
        
        const { data, error } = await supabase
          .from('photos')
          .select('*')
          .eq('appointment_id', selectedAppointment)
          .order('created_at', { ascending: false })
        
        if (error) throw error
        
        if (data) {
          setAppointmentPhotos(data)
          setFilteredPhotos(data)
        }
      } catch (error) {
        console.error('Error fetching photos:', error)
        toast.error('Failed to load photos')
      } finally {
        setLoading(false)
      }
    }
    
    fetchPhotos()
  }, [selectedAppointment])
  
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredPhotos(appointmentPhotos)
    } else {
      const filtered = appointmentPhotos.filter(photo => 
        photo.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
        (photo.description && photo.description.toLowerCase().includes(searchQuery.toLowerCase()))
      )
      setFilteredPhotos(filtered)
    }
  }, [searchQuery, appointmentPhotos])
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }
  
  const handleAppointmentChange = (appointmentId: string) => {
    setSelectedAppointment(appointmentId)
    setSelectedPhoto(null)
    setSearchQuery('')
  }
  
  const handlePhotoClick = (photo: Photo, index: number) => {
    setSelectedPhoto(photo)
    setCurrentPhotoIndex(index)
  }
  
  const handleCloseModal = () => {
    setSelectedPhoto(null)
  }
  
  const handlePrevPhoto = () => {
    if (currentPhotoIndex > 0) {
      setCurrentPhotoIndex(currentPhotoIndex - 1)
      setSelectedPhoto(filteredPhotos[currentPhotoIndex - 1])
    }
  }
  
  const handleNextPhoto = () => {
    if (currentPhotoIndex < filteredPhotos.length - 1) {
      setCurrentPhotoIndex(currentPhotoIndex + 1)
      setSelectedPhoto(filteredPhotos[currentPhotoIndex + 1])
    }
  }
  
  const handleDownload = (url: string) => {
    // In a real app, you would handle the download properly
    // For this demo, we'll just open the image in a new tab
    window.open(url, '_blank')
    toast.success('Download started')
  }
  
  if (loading && appointments.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    )
  }
  
  if (appointments.length === 0) {
    return (
      <div className="max-w-4xl mx-auto text-center py-12">
        <h1 className="text-3xl font-bold mb-4">No Photos Available</h1>
        <p className="text-gray-600 mb-6">
          You don't have any completed photography sessions yet. Photos will appear here after your session is completed.
        </p>
        <button
          onClick={() => window.location.href = '/dashboard/booking'}
          className="btn-primary"
        >
          Book a Session
        </button>
      </div>
    )
  }
  
  return (
    <div className="max-w-6xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold mb-2">My Photos</h1>
        <p className="text-gray-600">
          View and download photos from your completed photography sessions.
        </p>
      </motion.div>
      
      {/* Session selector and search */}
      <div className="mb-8 flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div className="md:w-1/2">
          <label htmlFor="session" className="block text-gray-700 font-medium mb-2">
            Select Session
          </label>
          <select
            id="session"
            value={selectedAppointment || ''}
            onChange={(e) => handleAppointmentChange(e.target.value)}
            className="form-input"
          >
            {appointments.map((appointment) => (
              <option key={appointment.id} value={appointment.id}>
                {appointment.package.name} - {formatDate(appointment.date)}
              </option>
            ))}
          </select>
        </div>
        
        <div className="md:w-1/2">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search photos by title or description"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="form-input pl-10"
            />
          </div>
        </div>
      </div>
      
      {/* Photo grid */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      ) : filteredPhotos.length === 0 ? (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white rounded-lg shadow-md p-12 text-center"
        >
          <h2 className="text-xl font-bold mb-2">No Photos Available</h2>
          <p className="text-gray-600">
            {searchQuery ? 
              'No photos match your search criteria. Try a different search term.' : 
              'There are no photos available for this session yet. Photos are typically available 7-10 business days after your session.'}
          </p>
        </motion.div>
      ) : (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
        >
          {filteredPhotos.map((photo, index) => (
            <motion.div 
              key={photo.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className="bg-white rounded-lg overflow-hidden shadow-md cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
              onClick={() => handlePhotoClick(photo, index)}
            >
              <div className="aspect-ratio-portrait">
                <img 
                  src={photo.thumbnail_url || photo.url || `https://images.pexels.com/photos/${1000000 + index * 100}/pexels-photo-${1000000 + index * 100}.jpeg?auto=compress&cs=tinysrgb&w=600`} 
                  alt={photo.title} 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4">
                <h3 className="font-bold text-gray-900 truncate">{photo.title}</h3>
                <p className="text-gray-500 text-sm truncate">{photo.description}</p>
                <p className="text-xs text-gray-400 mt-2">{formatDate(photo.created_at)}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}
      
      {/* Photo modal */}
      <AnimatePresence>
        {selectedPhoto && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4"
            onClick={handleCloseModal}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-lg max-w-5xl w-full max-h-[90vh] overflow-hidden flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                <h3 className="font-bold text-lg">{selectedPhoto.title}</h3>
                <button 
                  onClick={handleCloseModal}
                  className="text-gray-500 hover:text-gray-700 transition-colors duration-200"
                >
                  <XMarkIcon className="h-6 w-6" />
                </button>
              </div>
              
              <div className="flex-1 overflow-auto p-4 relative">
                <img 
                  src={selectedPhoto.url || `https://images.pexels.com/photos/${1000000 + currentPhotoIndex * 100}/pexels-photo-${1000000 + currentPhotoIndex * 100}.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1`} 
                  alt={selectedPhoto.title} 
                  className="max-w-full max-h-[60vh] mx-auto object-contain"
                />
                
                {/* Navigation buttons */}
                <button
                  onClick={handlePrevPhoto}
                  disabled={currentPhotoIndex === 0}
                  className={`absolute left-4 top-1/2 transform -translate-y-1/2 p-2 rounded-full bg-white bg-opacity-80 shadow-md ${
                    currentPhotoIndex === 0 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-opacity-100'
                  }`}
                >
                  <ChevronLeftIcon className="h-6 w-6 text-gray-800" />
                </button>
                
                <button
                  onClick={handleNextPhoto}
                  disabled={currentPhotoIndex === filteredPhotos.length - 1}
                  className={`absolute right-4 top-1/2 transform -translate-y-1/2 p-2 rounded-full bg-white bg-opacity-80 shadow-md ${
                    currentPhotoIndex === filteredPhotos.length - 1 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-opacity-100'
                  }`}
                >
                  <ChevronRightIcon className="h-6 w-6 text-gray-800" />
                </button>
                
                <div className="mt-6">
                  <p className="text-gray-700">{selectedPhoto.description}</p>
                  <p className="text-sm text-gray-500 mt-2">Taken on {formatDate(selectedPhoto.created_at)}</p>
                </div>
              </div>
              
              <div className="p-4 border-t border-gray-200 flex justify-between items-center">
                <div className="text-sm text-gray-500">
                  Photo {currentPhotoIndex + 1} of {filteredPhotos.length}
                </div>
                <button
                  onClick={() => handleDownload(selectedPhoto.url)}
                  className="flex items-center px-4 py-2 bg-primary-600 text-white font-medium rounded-md shadow-sm hover:bg-primary-700 transition-colors duration-200"
                >
                  <ArrowDownTrayIcon className="h-5 w-5 mr-2" />
                  Download
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default MyPhotosPage
