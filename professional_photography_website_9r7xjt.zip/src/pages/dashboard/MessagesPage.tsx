import { useState, useEffect, useRef } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import { format } from 'date-fns'
import {
  PaperAirplaneIcon,
  PhotoIcon,
  DocumentIcon,
  FaceSmileIcon,
  PaperClipIcon
} from '@heroicons/react/24/outline'

interface Message {
  id: string
  sender_id: string
  receiver_id: string
  content: string
  created_at: string
  is_read: boolean
  sender_name: string
  sender_avatar?: string
}

interface Conversation {
  id: string
  user_id: string
  user_name: string
  user_avatar?: string
  last_message: string
  last_message_time: string
  unread_count: number
}

const MessagesPage = () => {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [sending, setSending] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Mock data for conversations
  useEffect(() => {
    if (!user) return
    
    // In a real app, you would fetch this from your database
    const mockConversations: Conversation[] = [
      {
        id: '1',
        user_id: 'admin',
        user_name: 'Derrick (Photographer)',
        user_avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600',
        last_message: 'Your photos are ready! You can view them in your dashboard.',
        last_message_time: new Date().toISOString(),
        unread_count: 1
      },
      {
        id: '2',
        user_id: 'support',
        user_name: 'DXM Support',
        user_avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600',
        last_message: 'How can we help you today?',
        last_message_time: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
        unread_count: 0
      }
    ]
    
    setConversations(mockConversations)
    setSelectedConversation(mockConversations[0])
    setLoading(false)
  }, [user])

  // Mock data for messages
  useEffect(() => {
    if (!selectedConversation) return
    
    // In a real app, you would fetch this from your database
    const mockMessages: Message[] = [
      {
        id: '1',
        sender_id: selectedConversation.user_id,
        receiver_id: user?.id || '',
        content: 'Hello! How can I help you today?',
        created_at: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
        is_read: true,
        sender_name: selectedConversation.user_name
      },
      {
        id: '2',
        sender_id: user?.id || '',
        receiver_id: selectedConversation.user_id,
        content: 'Hi! I was wondering when my photos will be ready from my session last week.',
        created_at: new Date(Date.now() - 3500000).toISOString(), // 58 minutes ago
        is_read: true,
        sender_name: 'You'
      },
      {
        id: '3',
        sender_id: selectedConversation.user_id,
        receiver_id: user?.id || '',
        content: 'Great news! Your photos are ready now. You can view and download them from your dashboard.',
        created_at: new Date(Date.now() - 3400000).toISOString(), // 56 minutes ago
        is_read: true,
        sender_name: selectedConversation.user_name
      },
      {
        id: '4',
        sender_id: selectedConversation.user_id,
        receiver_id: user?.id || '',
        content: 'Let me know if you have any questions about the photos or if you need anything else!',
        created_at: new Date(Date.now() - 60000).toISOString(), // 1 minute ago
        is_read: false,
        sender_name: selectedConversation.user_name
      }
    ]
    
    setMessages(mockMessages)
    
    // Mark conversation as read
    setConversations(conversations.map(conv => 
      conv.id === selectedConversation.id 
        ? { ...conv, unread_count: 0 }
        : conv
    ))
  }, [selectedConversation, user])

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSelectConversation = (conversation: Conversation) => {
    setSelectedConversation(conversation)
  }

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation || !user) return
    
    try {
      setSending(true)
      
      // In a real app, you would save this to your database
      const newMsg: Message = {
        id: Date.now().toString(),
        sender_id: user.id,
        receiver_id: selectedConversation.user_id,
        content: newMessage,
        created_at: new Date().toISOString(),
        is_read: false,
        sender_name: 'You'
      }
      
      // Add to messages
      setMessages([...messages, newMsg])
      
      // Update conversation
      setConversations(conversations.map(conv => 
        conv.id === selectedConversation.id 
          ? { 
              ...conv, 
              last_message: newMessage,
              last_message_time: new Date().toISOString()
            }
          : conv
      ))
      
      // Clear input
      setNewMessage('')
      
      // Simulate response after 1 second
      setTimeout(() => {
        const response: Message = {
          id: (Date.now() + 1).toString(),
          sender_id: selectedConversation.user_id,
          receiver_id: user.id,
          content: "Thanks for your message! I'll get back to you as soon as possible.",
          created_at: new Date().toISOString(),
          is_read: false,
          sender_name: selectedConversation.user_name
        }
        
        setMessages(prev => [...prev, response])
      }, 1000)
    } catch (error) {
      console.error('Error sending message:', error)
    } finally {
      setSending(false)
    }
  }

  const formatMessageTime = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    
    // If today, show time
    if (date.toDateString() === now.toDateString()) {
      return format(date, 'h:mm a')
    }
    
    // If this year, show month and day
    if (date.getFullYear() === now.getFullYear()) {
      return format(date, 'MMM d')
    }
    
    // Otherwise show full date
    return format(date, 'MMM d, yyyy')
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Messages</h1>
        <p className="text-gray-600">
          Communicate with your photographer and support team.
        </p>
      </div>
      
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="flex h-[calc(80vh-200px)]">
          {/* Conversations sidebar */}
          <div className="w-1/3 border-r border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Conversations</h2>
            </div>
            
            <div className="overflow-y-auto h-full">
              {conversations.length === 0 ? (
                <div className="p-4 text-center text-gray-500">
                  No conversations yet.
                </div>
              ) : (
                <ul className="divide-y divide-gray-200">
                  {conversations.map((conversation) => (
                    <li
                      key={conversation.id}
                      className={`hover:bg-gray-50 cursor-pointer ${
                        selectedConversation?.id === conversation.id ? 'bg-primary-50' : ''
                      }`}
                      onClick={() => handleSelectConversation(conversation)}
                    >
                      <div className="p-4">
                        <div className="flex items-center space-x-3">
                          <div className="flex-shrink-0">
                            {conversation.user_avatar ? (
                              <img
                                src={conversation.user_avatar}
                                alt={conversation.user_name}
                                className="h-10 w-10 rounded-full"
                              />
                            ) : (
                              <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-800 font-semibold">
                                {conversation.user_name.charAt(0)}
                              </div>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium text-gray-900 truncate">
                                {conversation.user_name}
                              </p>
                              <p className="text-xs text-gray-500">
                                {formatMessageTime(conversation.last_message_time)}
                              </p>
                            </div>
                            <div className="flex items-center justify-between">
                              <p className="text-sm text-gray-500 truncate">
                                {conversation.last_message}
                              </p>
                              {conversation.unread_count > 0 && (
                                <span className="inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white bg-primary-600 rounded-full">
                                  {conversation.unread_count}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
          
          {/* Messages */}
          <div className="w-2/3 flex flex-col">
            {selectedConversation ? (
              <>
                <div className="p-4 border-b border-gray-200 flex items-center space-x-3">
                  <div className="flex-shrink-0">
                    {selectedConversation.user_avatar ? (
                      <img
                        src={selectedConversation.user_avatar}
                        alt={selectedConversation.user_name}
                        className="h-10 w-10 rounded-full"
                      />
                    ) : (
                      <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-800 font-semibold">
                        {selectedConversation.user_name.charAt(0)}
                      </div>
                    )}
                  </div>
                  <div>
                    <h2 className="text-lg font-medium text-gray-900">
                      {selectedConversation.user_name}
                    </h2>
                    <p className="text-sm text-gray-500">
                      {selectedConversation.user_id === 'admin' ? 'Photographer' : 'Support Team'}
                    </p>
                  </div>
                </div>
                
                <div className="flex-1 p-4 overflow-y-auto">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${
                          message.sender_id === user?.id ? 'justify-end' : 'justify-start'
                        }`}
                      >
                        <div
                          className={`max-w-xs md:max-w-md rounded-lg px-4 py-2 ${
                            message.sender_id === user?.id
                              ? 'bg-primary-600 text-white'
                              : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          <p>{message.content}</p>
                          <p
                            className={`text-xs mt-1 ${
                              message.sender_id === user?.id ? 'text-primary-100' : 'text-gray-500'
                            }`}
                          >
                            {formatMessageTime(message.created_at)}
                          </p>
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                </div>
                
                <div className="p-4 border-t border-gray-200">
                  <div className="flex items-center">
                    <button
                      type="button"
                      className="inline-flex items-center justify-center rounded-full h-10 w-10 text-gray-500 hover:text-gray-600"
                    >
                      <PaperClipIcon className="h-5 w-5" />
                    </button>
                    <button
                      type="button"
                      className="inline-flex items-center justify-center rounded-full h-10 w-10 text-gray-500 hover:text-gray-600"
                    >
                      <PhotoIcon className="h-5 w-5" />
                    </button>
                    <button
                      type="button"
                      className="inline-flex items-center justify-center rounded-full h-10 w-10 text-gray-500 hover:text-gray-600"
                    >
                      <DocumentIcon className="h-5 w-5" />
                    </button>
                    <button
                      type="button"
                      className="inline-flex items-center justify-center rounded-full h-10 w-10 text-gray-500 hover:text-gray-600"
                    >
                      <FaceSmileIcon className="h-5 w-5" />
                    </button>
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Type a message..."
                      className="flex-1 border-0 focus:ring-0 focus:outline-none px-4 py-2"
                    />
                    <button
                      type="button"
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim() || sending}
                      className={`inline-flex items-center justify-center rounded-full h-10 w-10 ${
                        !newMessage.trim() || sending
                          ? 'text-gray-400 cursor-not-allowed'
                          : 'text-primary-600 hover:text-primary-700'
                      }`}
                    >
                      <PaperAirplaneIcon className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <div className="mx-auto h-12 w-12 text-gray-400">
                    <svg className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1}
                        d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                      />
                    </svg>
                  </div>
                  <h3 className="mt-2 text-sm font-medium text-gray-900">No conversation selected</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Select a conversation to start messaging.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default MessagesPage
