import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import { motion } from 'framer-motion'
import {
  CalendarIcon,
  PhotoIcon,
  CreditCardIcon,
  ChatBubbleLeftRightIcon,
  ArrowRightIcon,
  CheckCircleIcon,
  ClockIcon,
  ExclamationCircleIcon
} from '@heroicons/react/24/outline'

interface Appointment {
  id: string
  date: string
  time: string
  location: string
  status: string
  package: {
    name: string
    price: number
  }
}

interface PhotoSession {
  id: string
  appointment_id: string
  photos: string[]
  status: string
}

const DashboardPage = () => {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [upcomingAppointments, setUpcomingAppointments] = useState<Appointment[]>([])
  const [recentPhotos, setRecentPhotos] = useState<any[]>([])
  const [stats, setStats] = useState({
    totalAppointments: 0,
    completedSessions: 0,
    totalPhotos: 0,
    unreadMessages: 2 // Hardcoded for demo
  })

  useEffect(() => {
    const fetchDashboardData = async () => {
      if (!user) return
      
      try {
        setLoading(true)
        
        // Fetch upcoming appointments
        const { data: appointmentsData, error: appointmentsError } = await supabase
          .from('appointments')
          .select(`
            id,
            date,
            time,
            location,
            status,
            package:packages(name, price)
          `)
          .eq('user_id', user.id)
          .in('status', ['scheduled', 'confirmed'])
          .order('date', { ascending: true })
          .limit(3)
        
        if (appointmentsError) throw appointmentsError
        
        if (appointmentsData) {
          setUpcomingAppointments(appointmentsData as Appointment[])
        }
        
        // Fetch recent photos
        const { data: photoSessionsData, error: photoSessionsError } = await supabase
          .from('photo_sessions')
          .select(`
            id,
            appointment_id,
            photos,
            status,
            appointments(
              id,
              date,
              package:packages(name)
            )
          `)
          .eq('appointments.user_id', user.id)
          .eq('status', 'completed')
          .order('created_at', { ascending: false })
          .limit(4)
        
        if (photoSessionsError) throw photoSessionsError
        
        if (photoSessionsData) {
          // Extract photos from sessions
          let photos: any[] = []
          photoSessionsData.forEach((session: any) => {
            if (session.photos && session.photos.length > 0) {
              const sessionPhotos = session.photos.slice(0, 4).map((photoUrl: string) => ({
                url: photoUrl,
                session_id: session.id,
                appointment_id: session.appointment_id,
                date: session.appointments?.date,
                package_name: session.appointments?.package?.name
              }))
              photos = [...photos, ...sessionPhotos]
            }
          })
          setRecentPhotos(photos.slice(0, 4))
        }
        
        // Fetch stats
        const { data: statsData, error: statsError } = await supabase
          .from('appointments')
          .select('id, status')
          .eq('user_id', user.id)
        
        if (statsError) throw statsError
        
        if (statsData) {
          const completedCount = statsData.filter(app => app.status === 'completed').length
          setStats({
            totalAppointments: statsData.length,
            completedSessions: completedCount,
            totalPhotos: recentPhotos.length,
            unreadMessages: 2 // Hardcoded for demo
          })
        }
      } catch (error) {
        console.error('Error fetching dashboard data:', error)
      } finally {
        setLoading(false)
      }
    }
    
    fetchDashboardData()
  }, [user])
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircleIcon className="mr-1 h-3 w-3" />
            Confirmed
          </span>
        )
      case 'scheduled':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <ClockIcon className="mr-1 h-3 w-3" />
            Scheduled
          </span>
        )
      case 'pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <ExclamationCircleIcon className="mr-1 h-3 w-3" />
            Pending
          </span>
        )
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        )
    }
  }
  
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    )
  }
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Welcome back{user?.email ? `, ${user.email.split('@')[0]}` : ''}!</h1>
        <p className="mt-1 text-gray-500">
          Here's what's happening with your photography sessions.
        </p>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="dashboard-card p-5"
        >
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <CalendarIcon className="h-10 w-10 text-primary-600" />
            </div>
            <div className="ml-5">
              <p className="text-sm font-medium text-gray-500 truncate">
                Total Appointments
              </p>
              <p className="mt-1 text-3xl font-semibold text-gray-900">
                {stats.totalAppointments}
              </p>
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="dashboard-card p-5"
        >
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <CheckCircleIcon className="h-10 w-10 text-green-600" />
            </div>
            <div className="ml-5">
              <p className="text-sm font-medium text-gray-500 truncate">
                Completed Sessions
              </p>
              <p className="mt-1 text-3xl font-semibold text-gray-900">
                {stats.completedSessions}
              </p>
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="dashboard-card p-5"
        >
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <PhotoIcon className="h-10 w-10 text-indigo-600" />
            </div>
            <div className="ml-5">
              <p className="text-sm font-medium text-gray-500 truncate">
                Available Photos
              </p>
              <p className="mt-1 text-3xl font-semibold text-gray-900">
                {stats.totalPhotos}
              </p>
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="dashboard-card p-5"
        >
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ChatBubbleLeftRightIcon className="h-10 w-10 text-secondary-600" />
            </div>
            <div className="ml-5">
              <p className="text-sm font-medium text-gray-500 truncate">
                Unread Messages
              </p>
              <p className="mt-1 text-3xl font-semibold text-gray-900">
                {stats.unreadMessages}
              </p>
            </div>
          </div>
        </motion.div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upcoming Appointments */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="dashboard-card overflow-visible"
        >
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium text-gray-900">Upcoming Appointments</h2>
              <Link to="/dashboard/appointments" className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center">
                View all
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
          
          <div className="divide-y divide-gray-200">
            {upcomingAppointments.length === 0 ? (
              <div className="p-6 text-center">
                <p className="text-gray-500">No upcoming appointments.</p>
                <Link to="/dashboard/booking" className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700">
                  Book a Session
                </Link>
              </div>
            ) : (
              upcomingAppointments.map((appointment, index) => (
                <div key={appointment.id} className="p-6 hover:bg-gray-50 transition-colors duration-150">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {appointment.package?.name || 'Photography Session'}
                      </p>
                      <div className="mt-1 flex items-center">
                        <CalendarIcon className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        <p className="text-sm text-gray-500">
                          {formatDate(appointment.date)} at {appointment.time}
                        </p>
                      </div>
                      <div className="mt-1 flex items-center">
                        <svg className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                        </svg>
                        <p className="text-sm text-gray-500 truncate">
                          {appointment.location}
                        </p>
                      </div>
                    </div>
                    <div className="ml-4 flex-shrink-0 flex flex-col items-end">
                      {getStatusBadge(appointment.status)}
                      <p className="mt-1 text-sm font-medium text-gray-900">
                        ${appointment.package?.price}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <Link
                      to={`/dashboard/appointments/${appointment.id}`}
                      className="text-sm font-medium text-primary-600 hover:text-primary-700"
                    >
                      View details
                    </Link>
                  </div>
                </div>
              ))
            )}
          </div>
        </motion.div>
        
        {/* Recent Photos */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="dashboard-card overflow-visible"
        >
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium text-gray-900">Recent Photos</h2>
              <Link to="/dashboard/photos" className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center">
                View all
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
          
          {recentPhotos.length === 0 ? (
            <div className="p-6 text-center">
              <p className="text-gray-500">No photos available yet.</p>
              <p className="mt-2 text-sm text-gray-500">
                Photos will appear here after your sessions are completed.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 p-6">
              {recentPhotos.map((photo, index) => (
                <div key={index} className="image-hover-effect rounded-lg overflow-hidden shadow-sm">
                  <Link to="/dashboard/photos">
                    <div className="aspect-ratio-square">
                      <img
                        src={photo.url || `https://images.pexels.com/photos/${1000000 + index * 100}/pexels-photo-${1000000 + index * 100}.jpeg?auto=compress&cs=tinysrgb&w=600`}
                        alt={`Recent photo ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-2">
                      <p className="text-xs text-gray-500 truncate">
                        {photo.package_name || 'Photography Session'}
                      </p>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
      
      {/* Quick Actions */}
      <div className="mt-8">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link
            to="/dashboard/booking"
            className="dashboard-card p-6 flex items-center hover:bg-gray-50 transition-colors duration-150"
          >
            <CreditCardIcon className="h-8 w-8 text-primary-600 mr-4" />
            <div>
              <h3 className="text-base font-medium text-gray-900">Book a Session</h3>
              <p className="mt-1 text-sm text-gray-500">
                Schedule your next photography session
              </p>
            </div>
          </Link>
          
          <Link
            to="/dashboard/photos"
            className="dashboard-card p-6 flex items-center hover:bg-gray-50 transition-colors duration-150"
          >
            <PhotoIcon className="h-8 w-8 text-indigo-600 mr-4" />
            <div>
              <h3 className="text-base font-medium text-gray-900">View Photos</h3>
              <p className="mt-1 text-sm text-gray-500">
                Browse and download your photos
              </p>
            </div>
          </Link>
          
          <Link
            to="/dashboard/messages"
            className="dashboard-card p-6 flex items-center hover:bg-gray-50 transition-colors duration-150"
          >
            <ChatBubbleLeftRightIcon className="h-8 w-8 text-secondary-600 mr-4" />
            <div>
              <h3 className="text-base font-medium text-gray-900">Messages</h3>
              <p className="mt-1 text-sm text-gray-500">
                Contact your photographer
              </p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  )
}

export default DashboardPage
