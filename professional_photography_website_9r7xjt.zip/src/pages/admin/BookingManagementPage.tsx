import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import toast from 'react-hot-toast'
import {
  CalendarIcon,
  CheckCircleIcon,
  ClockIcon,
  ExclamationCircleIcon,
  XCircleIcon,
  EnvelopeIcon,
  PaperAirplaneIcon,
  MagnifyingGlassIcon,
  ArrowPathIcon
} from '@heroicons/react/24/outline'

interface Appointment {
  id: string
  user_id: string
  date: string
  time: string
  location: string
  status: string
  notes: string | null
  payment_status: string
  user_email: string
  user_name: string
  user_phone: string
  package_name: string
  package_price: number
}

interface EmailTemplate {
  id: string
  name: string
  subject: string
  body: string
}

const BookingManagementPage = () => {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [filteredAppointments, setFilteredAppointments] = useState<Appointment[]>([])
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null)
  const [statusFilter, setStatusFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [emailTemplates, setEmailTemplates] = useState<EmailTemplate[]>([
    {
      id: '1',
      name: 'Appointment Confirmation',
      subject: 'Your appointment with DXM Productions has been confirmed',
      body: 'Dear {client_name},\n\nYour appointment for {package_name} on {appointment_date} at {appointment_time} has been confirmed.\n\nLocation: {location}\n\nIf you need to reschedule or have any questions, please contact us.\n\nBest regards,\nDXM Productions'
    },
    {
      id: '2',
      name: 'Appointment Reminder',
      subject: 'Reminder: Your upcoming photography session',
      body: 'Dear {client_name},\n\nThis is a friendly reminder about your upcoming photography session:\n\nDate: {appointment_date}\nTime: {appointment_time}\nLocation: {location}\nPackage: {package_name}\n\nPlease arrive 10 minutes early. If you need to reschedule, please contact us at least 24 hours in advance.\n\nWe look forward to seeing you!\n\nBest regards,\nDXM Productions'
    },
    {
      id: '3',
      name: 'Photos Ready',
      subject: 'Your photos are ready!',
      body: 'Dear {client_name},\n\nGreat news! Your photos from your recent {package_name} session are now ready to view.\n\nYou can log in to your client portal to view and download your photos.\n\nIf you have any questions or need assistance, please don\'t hesitate to contact us.\n\nBest regards,\nDXM Productions'
    }
  ])
  const [selectedTemplate, setSelectedTemplate] = useState<string>('')
  const [emailSubject, setEmailSubject] = useState('')
  const [emailBody, setEmailBody] = useState('')
  const [sendingEmail, setSendingEmail] = useState(false)

  // Fetch appointments
  useEffect(() => {
    const fetchAppointments = async () => {
      if (!user) return
      
      try {
        setLoading(true)
        
        const { data, error } = await supabase
          .from('appointments')
          .select(`
            id,
            user_id,
            date,
            time,
            location,
            status,
            notes,
            payment_status,
            profiles(email, full_name, phone),
            packages(name, price)
          `)
          .order('date', { ascending: false })
        
        if (error) throw error
        
        if (data) {
          const formattedAppointments = data.map(item => ({
            id: item.id,
            user_id: item.user_id,
            date: item.date,
            time: item.time,
            location: item.location,
            status: item.status,
            notes: item.notes,
            payment_status: item.payment_status,
            user_email: item.profiles?.email || 'Unknown',
            user_name: item.profiles?.full_name || 'Unknown',
            user_phone: item.profiles?.phone || 'Unknown',
            package_name: item.packages?.name || 'Unknown',
            package_price: item.packages?.price || 0
          }))
          
          setAppointments(formattedAppointments)
          setFilteredAppointments(formattedAppointments)
        }
      } catch (error) {
        console.error('Error fetching appointments:', error)
        toast.error('Failed to load appointments')
      } finally {
        setLoading(false)
      }
    }
    
    fetchAppointments()
  }, [user])

  // Filter appointments based on status and search query
  useEffect(() => {
    let filtered = appointments
    
    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(appointment => appointment.status === statusFilter)
    }
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(appointment => 
        appointment.user_email.toLowerCase().includes(query) ||
        appointment.user_name.toLowerCase().includes(query) ||
        appointment.package_name.toLowerCase().includes(query) ||
        appointment.location.toLowerCase().includes(query)
      )
    }
    
    setFilteredAppointments(filtered)
  }, [statusFilter, searchQuery, appointments])

  // Handle appointment selection
  const handleSelectAppointment = (appointment: Appointment) => {
    setSelectedAppointment(appointment)
    setSelectedTemplate('')
    setEmailSubject('')
    setEmailBody('')
  }

  // Handle status update
  const handleUpdateStatus = async (appointmentId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('appointments')
        .update({ status: newStatus })
        .eq('id', appointmentId)
      
      if (error) throw error
      
      // Update local state
      setAppointments(appointments.map(appointment => 
        appointment.id === appointmentId 
          ? { ...appointment, status: newStatus }
          : appointment
      ))
      
      if (selectedAppointment && selectedAppointment.id === appointmentId) {
        setSelectedAppointment({ ...selectedAppointment, status: newStatus })
      }
      
      toast.success(`Appointment status updated to ${newStatus}`)
    } catch (error) {
      console.error('Error updating appointment status:', error)
      toast.error('Failed to update appointment status')
    }
  }

  // Handle payment status update
  const handleUpdatePaymentStatus = async (appointmentId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('appointments')
        .update({ payment_status: newStatus })
        .eq('id', appointmentId)
      
      if (error) throw error
      
      // Update local state
      setAppointments(appointments.map(appointment => 
        appointment.id === appointmentId 
          ? { ...appointment, payment_status: newStatus }
          : appointment
      ))
      
      if (selectedAppointment && selectedAppointment.id === appointmentId) {
        setSelectedAppointment({ ...selectedAppointment, payment_status: newStatus })
      }
      
      toast.success(`Payment status updated to ${newStatus}`)
    } catch (error) {
      console.error('Error updating payment status:', error)
      toast.error('Failed to update payment status')
    }
  }

  // Handle notes update
  const handleUpdateNotes = async (appointmentId: string, notes: string) => {
    try {
      const { error } = await supabase
        .from('appointments')
        .update({ notes })
        .eq('id', appointmentId)
      
      if (error) throw error
      
      // Update local state
      setAppointments(appointments.map(appointment => 
        appointment.id === appointmentId 
          ? { ...appointment, notes }
          : appointment
      ))
      
      if (selectedAppointment && selectedAppointment.id === appointmentId) {
        setSelectedAppointment({ ...selectedAppointment, notes })
      }
      
      toast.success('Notes updated successfully')
    } catch (error) {
      console.error('Error updating notes:', error)
      toast.error('Failed to update notes')
    }
  }

  // Handle template selection
  const handleTemplateChange = (templateId: string) => {
    setSelectedTemplate(templateId)
    
    if (!selectedAppointment) return
    
    const template = emailTemplates.find(t => t.id === templateId)
    if (template) {
      // Replace placeholders with actual values
      const subject = template.subject
      let body = template.body
        .replace('{client_name}', selectedAppointment.user_name)
        .replace('{package_name}', selectedAppointment.package_name)
        .replace('{appointment_date}', formatDate(selectedAppointment.date))
        .replace('{appointment_time}', selectedAppointment.time)
        .replace('{location}', selectedAppointment.location)
      
      setEmailSubject(subject)
      setEmailBody(body)
    }
  }

  // Handle email sending
  const handleSendEmail = async () => {
    if (!selectedAppointment) return
    
    // In a real app, you would send the email through your backend
    // For this demo, we'll just simulate sending
    setSendingEmail(true)
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      toast.success(`Email sent to ${selectedAppointment.user_email}`)
      
      // In a real app, you might want to record that an email was sent
      const updatedNotes = selectedAppointment.notes 
        ? `${selectedAppointment.notes}\n\n[${new Date().toLocaleString()}] Email sent: ${emailSubject}`
        : `[${new Date().toLocaleString()}] Email sent: ${emailSubject}`
      
      await handleUpdateNotes(selectedAppointment.id, updatedNotes)
    } catch (error) {
      console.error('Error sending email:', error)
      toast.error('Failed to send email')
    } finally {
      setSendingEmail(false)
    }
  }

  // Format date
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircleIcon className="mr-1 h-3 w-3" />
            Confirmed
          </span>
        )
      case 'scheduled':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <ClockIcon className="mr-1 h-3 w-3" />
            Scheduled
          </span>
        )
      case 'pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <ExclamationCircleIcon className="mr-1 h-3 w-3" />
            Pending
          </span>
        )
      case 'cancelled':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <XCircleIcon className="mr-1 h-3 w-3" />
            Cancelled
          </span>
        )
      case 'completed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
            <CheckCircleIcon className="mr-1 h-3 w-3" />
            Completed
          </span>
        )
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        )
    }
  }

  // Get payment status badge
  const getPaymentStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            Paid
          </span>
        )
      case 'pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            Pending
          </span>
        )
      case 'refunded':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            Refunded
          </span>
        )
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        )
    }
  }

  if (loading && appointments.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Booking Management</h1>
        <p className="mt-1 text-gray-500">
          Manage appointments and communicate with clients.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Appointments list */}
        <div className="lg:col-span-1">
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <div className="flex flex-col space-y-4">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search appointments..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="form-input pl-10"
                  />
                </div>
                
                <div className="flex space-x-2">
                  <button
                    onClick={() => setStatusFilter('all')}
                    className={`px-3 py-1 rounded-md text-sm font-medium ${
                      statusFilter === 'all'
                        ? 'bg-primary-100 text-primary-800'
                        : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    All
                  </button>
                  <button
                    onClick={() => setStatusFilter('confirmed')}
                    className={`px-3 py-1 rounded-md text-sm font-medium ${
                      statusFilter === 'confirmed'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Confirmed
                  </button>
                  <button
                    onClick={() => setStatusFilter('pending')}
                    className={`px-3 py-1 rounded-md text-sm font-medium ${
                      statusFilter === 'pending'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Pending
                  </button>
                  <button
                    onClick={() => setStatusFilter('completed')}
                    className={`px-3 py-1 rounded-md text-sm font-medium ${
                      statusFilter === 'completed'
                        ? 'bg-indigo-100 text-indigo-800'
                        : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Completed
                  </button>
                </div>
              </div>
            </div>
            
            <div className="overflow-y-auto max-h-[calc(100vh-300px)]">
              {filteredAppointments.length === 0 ? (
                <div className="p-6 text-center">
                  <p className="text-gray-500">No appointments found.</p>
                </div>
              ) : (
                <ul className="divide-y divide-gray-200">
                  {filteredAppointments.map((appointment) => (
                    <li
                      key={appointment.id}
                      className={`hover:bg-gray-50 cursor-pointer ${
                        selectedAppointment?.id === appointment.id ? 'bg-primary-50' : ''
                      }`}
                      onClick={() => handleSelectAppointment(appointment)}
                    >
                      <div className="p-4">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {appointment.user_name || appointment.user_email}
                          </p>
                          {getStatusBadge(appointment.status)}
                        </div>
                        <div className="mt-2">
                          <div className="flex items-center text-sm text-gray-500">
                            <CalendarIcon className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                            <p>{formatDate(appointment.date)} at {appointment.time}</p>
                          </div>
                          <div className="mt-1 flex items-center text-sm text-gray-500">
                            <p className="truncate">{appointment.package_name} - ${appointment.package_price}</p>
                          </div>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
        
        {/* Appointment details and communication */}
        <div className="lg:col-span-2">
          {selectedAppointment ? (
            <div className="bg-white shadow rounded-lg overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-medium text-gray-900">
                    Appointment Details
                  </h2>
                  <div className="flex space-x-2">
                    {getStatusBadge(selectedAppointment.status)}
                    {getPaymentStatusBadge(selectedAppointment.payment_status)}
                  </div>
                </div>
              </div>
              
              <div className="p-6 border-b border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Client Information</h3>
                    <div className="mt-2 space-y-2">
                      <p className="text-sm text-gray-900">
                        <span className="font-medium">Name:</span> {selectedAppointment.user_name}
                      </p>
                      <p className="text-sm text-gray-900">
                        <span className="font-medium">Email:</span> {selectedAppointment.user_email}
                      </p>
                      <p className="text-sm text-gray-900">
                        <span className="font-medium">Phone:</span> {selectedAppointment.user_phone}
                      </p>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Appointment Information</h3>
                    <div className="mt-2 space-y-2">
                      <p className="text-sm text-gray-900">
                        <span className="font-medium">Package:</span> {selectedAppointment.package_name}
                      </p>
                      <p className="text-sm text-gray-900">
                        <span className="font-medium">Date:</span> {formatDate(selectedAppointment.date)}
                      </p>
                      <p className="text-sm text-gray-900">
                        <span className="font-medium">Time:</span> {selectedAppointment.time}
                      </p>
                      <p className="text-sm text-gray-900">
                        <span className="font-medium">Location:</span> {selectedAppointment.location}
                      </p>
                      <p className="text-sm text-gray-900">
                        <span className="font-medium">Price:</span> ${selectedAppointment.package_price}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-sm font-medium text-gray-500 mb-2">Update Status</h3>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => handleUpdateStatus(selectedAppointment.id, 'pending')}
                    className="px-3 py-1 rounded-md text-sm font-medium bg-yellow-100 text-yellow-800 hover:bg-yellow-200"
                  >
                    Pending
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(selectedAppointment.id, 'confirmed')}
                    className="px-3 py-1 rounded-md text-sm font-medium bg-green-100 text-green-800 hover:bg-green-200"
                  >
                    Confirm
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(selectedAppointment.id, 'completed')}
                    className="px-3 py-1 rounded-md text-sm font-medium bg-indigo-100 text-indigo-800 hover:bg-indigo-200"
                  >
                    Complete
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(selectedAppointment.id, 'cancelled')}
                    className="px-3 py-1 rounded-md text-sm font-medium bg-red-100 text-red-800 hover:bg-red-200"
                  >
                    Cancel
                  </button>
                </div>
                
                <h3 className="text-sm font-medium text-gray-500 mt-4 mb-2">Update Payment Status</h3>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => handleUpdatePaymentStatus(selectedAppointment.id, 'pending')}
                    className="px-3 py-1 rounded-md text-sm font-medium bg-yellow-100 text-yellow-800 hover:bg-yellow-200"
                  >
                    Pending
                  </button>
                  <button
                    onClick={() => handleUpdatePaymentStatus(selectedAppointment.id, 'paid')}
                    className="px-3 py-1 rounded-md text-sm font-medium bg-green-100 text-green-800 hover:bg-green-200"
                  >
                    Paid
                  </button>
                  <button
                    onClick={() => handleUpdatePaymentStatus(selectedAppointment.id, 'refunded')}
                    className="px-3 py-1 rounded-md text-sm font-medium bg-red-100 text-red-800 hover:bg-red-200"
                  >
                    Refunded
                  </button>
                </div>
              </div>
              
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-sm font-medium text-gray-500 mb-2">Notes</h3>
                <textarea
                  value={selectedAppointment.notes || ''}
                  onChange={(e) => setSelectedAppointment({ ...selectedAppointment, notes: e.target.value })}
                  onBlur={() => handleUpdateNotes(selectedAppointment.id, selectedAppointment.notes || '')}
                  className="form-input h-24 w-full"
                  placeholder="Add notes about this appointment..."
                />
              </div>
              
              <div className="p-6">
                <h3 className="text-sm font-medium text-gray-500 mb-4">Send Email to Client</h3>
                
                <div className="mb-4">
                  <label htmlFor="template" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Template
                  </label>
                  <select
                    id="template"
                    value={selectedTemplate}
                    onChange={(e) => handleTemplateChange(e.target.value)}
                    className="form-input"
                  >
                    <option value="">Select a template</option>
                    {emailTemplates.map((template) => (
                      <option key={template.id} value={template.id}>
                        {template.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="mb-4">
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    value={emailSubject}
                    onChange={(e) => setEmailSubject(e.target.value)}
                    className="form-input"
                    placeholder="Email subject"
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="body" className="block text-sm font-medium text-gray-700 mb-1">
                    Message
                  </label>
                  <textarea
                    id="body"
                    value={emailBody}
                    onChange={(e) => setEmailBody(e.target.value)}
                    className="form-input h-40"
                    placeholder="Email message"
                  />
                </div>
                
                <div className="flex justify-end">
                  <button
                    onClick={handleSendEmail}
                    disabled={!emailSubject || !emailBody || sendingEmail}
                    className={`flex items-center px-4 py-2 rounded-md text-sm font-medium ${
                      !emailSubject || !emailBody || sendingEmail
                        ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        : 'bg-primary-600 text-white hover:bg-primary-700'
                    }`}
                  >
                    {sendingEmail ? (
                      <>
                        <ArrowPathIcon className="animate-spin h-5 w-5 mr-2" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <PaperAirplaneIcon className="h-5 w-5 mr-2" />
                        Send Email
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white shadow rounded-lg p-12 text-center">
              <EnvelopeIcon className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-lg font-medium text-gray-900">No appointment selected</h3>
              <p className="mt-1 text-gray-500">
                Select an appointment from the list to view details and communicate with the client.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default BookingManagementPage
