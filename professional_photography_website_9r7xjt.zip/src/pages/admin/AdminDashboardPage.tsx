import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import {
  PhotoIcon,
  CalendarIcon,
  UsersIcon,
  CurrencyDollarIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  ArrowRightIcon
} from '@heroicons/react/24/outline'

const AdminDashboardPage = () => {
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalClients: 0,
    totalAppointments: 0,
    totalPhotos: 0,
    totalRevenue: 0,
    recentAppointments: [],
    recentClients: []
  })

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true)
        
        // In a real app, you would fetch this data from your database
        // For this demo, we'll use mock data
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        setStats({
          totalClients: 124,
          totalAppointments: 87,
          totalPhotos: 1432,
          totalRevenue: 24950,
          recentAppointments: [
            {
              id: '1',
              client_name: 'Sarah Johnson',
              package_name: 'Graduation',
              date: '2023-11-15',
              time: '10:00 AM',
              status: 'confirmed'
            },
            {
              id: '2',
              client_name: 'Michael Chen',
              package_name: 'Corporate Event',
              date: '2023-11-18',
              time: '2:00 PM',
              status: 'pending'
            },
            {
              id: '3',
              client_name: 'Emily Rodriguez',
              package_name: 'Family Portrait',
              date: '2023-11-20',
              time: '4:30 PM',
              status: 'confirmed'
            }
          ],
          recentClients: [
            {
              id: '1',
              name: 'John Smith',
              email: 'john.smith@example.com',
              joined_date: '2023-11-01'
            },
            {
              id: '2',
              name: 'Lisa Wong',
              email: 'lisa.wong@example.com',
              joined_date: '2023-11-05'
            },
            {
              id: '3',
              name: 'David Miller',
              email: 'david.miller@example.com',
              joined_date: '2023-11-10'
            }
          ]
        })
      } catch (error) {
        console.error('Error fetching dashboard data:', error)
      } finally {
        setLoading(false)
      }
    }
    
    fetchDashboardData()
  }, [])

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(amount)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            Confirmed
          </span>
        )
      case 'pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            Pending
          </span>
        )
      case 'cancelled':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            Cancelled
          </span>
        )
      case 'completed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
            Completed
          </span>
        )
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        )
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="mt-1 text-gray-500">
          Overview of your photography business.
        </p>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <UsersIcon className="h-10 w-10 text-primary-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Clients
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {stats.totalClients}
                    </div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                      <ArrowUpIcon className="self-center flex-shrink-0 h-4 w-4 text-green-500" aria-hidden="true" />
                      <span className="sr-only">Increased by</span>
                      12%
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/admin/clients" className="font-medium text-primary-600 hover:text-primary-700">
                View all
              </Link>
            </div>
          </div>
        </div>
        
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <CalendarIcon className="h-10 w-10 text-indigo-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Appointments
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {stats.totalAppointments}
                    </div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                      <ArrowUpIcon className="self-center flex-shrink-0 h-4 w-4 text-green-500" aria-hidden="true" />
                      <span className="sr-only">Increased by</span>
                      8%
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/admin/bookings" className="font-medium text-primary-600 hover:text-primary-700">
                View all
              </Link>
            </div>
          </div>
        </div>
        
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <PhotoIcon className="h-10 w-10 text-secondary-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Photos
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {stats.totalPhotos}
                    </div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                      <ArrowUpIcon className="self-center flex-shrink-0 h-4 w-4 text-green-500" aria-hidden="true" />
                      <span className="sr-only">Increased by</span>
                      24%
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/admin/photos" className="font-medium text-primary-600 hover:text-primary-700">
                View all
              </Link>
            </div>
          </div>
        </div>
        
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <CurrencyDollarIcon className="h-10 w-10 text-green-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Revenue
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {formatCurrency(stats.totalRevenue)}
                    </div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                      <ArrowUpIcon className="self-center flex-shrink-0 h-4 w-4 text-green-500" aria-hidden="true" />
                      <span className="sr-only">Increased by</span>
                      15%
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/admin/analytics" className="font-medium text-primary-600 hover:text-primary-700">
                View details
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Appointments */}
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium text-gray-900">Recent Appointments</h2>
              <Link to="/admin/bookings" className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center">
                View all
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
          
          <div className="divide-y divide-gray-200">
            {stats.recentAppointments.map((appointment: any) => (
              <div key={appointment.id} className="p-6 hover:bg-gray-50">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      {appointment.client_name}
                    </p>
                    <p className="text-sm text-gray-500">
                      {appointment.package_name}
                    </p>
                  </div>
                  <div>
                    {getStatusBadge(appointment.status)}
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm text-gray-500">
                  <CalendarIcon className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                  <p>
                    {formatDate(appointment.date)} at {appointment.time}
                  </p>
                </div>
                <div className="mt-2">
                  <Link
                    to={`/admin/bookings/${appointment.id}`}
                    className="text-sm font-medium text-primary-600 hover:text-primary-700"
                  >
                    View details
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Recent Clients */}
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium text-gray-900">Recent Clients</h2>
              <Link to="/admin/clients" className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center">
                View all
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
          
          <div className="divide-y divide-gray-200">
            {stats.recentClients.map((client: any) => (
              <div key={client.id} className="p-6 hover:bg-gray-50">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-800 font-semibold">
                      {client.name.charAt(0)}
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-900">
                      {client.name}
                    </p>
                    <p className="text-sm text-gray-500">
                      {client.email}
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      Joined {formatDate(client.joined_date)}
                    </p>
                  </div>
                </div>
                <div className="mt-2">
                  <Link
                    to={`/admin/clients/${client.id}`}
                    className="text-sm font-medium text-primary-600 hover:text-primary-700"
                  >
                    View profile
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Quick Actions */}
      <div className="mt-8">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link
            to="/admin/photos"
            className="bg-white p-6 rounded-lg shadow flex items-center hover:bg-gray-50 transition-colors duration-150"
          >
            <PhotoIcon className="h-8 w-8 text-primary-600 mr-4" />
            <div>
              <h3 className="text-base font-medium text-gray-900">Manage Photos</h3>
              <p className="mt-1 text-sm text-gray-500">
                Upload and organize client photos
              </p>
            </div>
          </Link>
          
          <Link
            to="/admin/bookings"
            className="bg-white p-6 rounded-lg shadow flex items-center hover:bg-gray-50 transition-colors duration-150"
          >
            <CalendarIcon className="h-8 w-8 text-indigo-600 mr-4" />
            <div>
              <h3 className="text-base font-medium text-gray-900">Manage Bookings</h3>
              <p className="mt-1 text-sm text-gray-500">
                View and update appointment status
              </p>
            </div>
          </Link>
          
          <Link
            to="/admin/emails"
            className="bg-white p-6 rounded-lg shadow flex items-center hover:bg-gray-50 transition-colors duration-150"
          >
            <svg className="h-8 w-8 text-secondary-600 mr-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
            <div>
              <h3 className="text-base font-medium text-gray-900">Email Clients</h3>
              <p className="mt-1 text-sm text-gray-500">
                Send updates and communications
              </p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  )
}

export default AdminDashboardPage
