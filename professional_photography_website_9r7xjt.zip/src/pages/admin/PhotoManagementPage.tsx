import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import { useDropzone } from 'react-dropzone'
import toast from 'react-hot-toast'
import {
  PhotoIcon,
  ArrowUpTrayIcon,
  TrashIcon,
  PencilIcon,
  CheckIcon,
  XMarkIcon,
  ArrowPathIcon,
  FolderIcon,
  UserIcon
} from '@heroicons/react/24/outline'

interface Appointment {
  id: string
  user_id: string
  date: string
  time: string
  location: string
  status: string
  user_email: string
  package_name: string
}

interface Photo {
  id: string
  user_id: string
  appointment_id: string
  url: string
  thumbnail_url: string
  title: string
  description: string
  created_at: string
  is_portfolio: boolean
}

const PhotoManagementPage = () => {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [uploading, setUploading] = useState(false)
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [selectedAppointment, setSelectedAppointment] = useState<string | null>(null)
  const [photos, setPhotos] = useState<Photo[]>([])
  const [uploadData, setUploadData] = useState({
    title: '',
    description: '',
    is_portfolio: false
  })
  const [editingPhoto, setEditingPhoto] = useState<string | null>(null)
  const [editData, setEditData] = useState({
    title: '',
    description: '',
    is_portfolio: false
  })
  const [filter, setFilter] = useState('all') // 'all', 'portfolio', 'client'

  // Fetch appointments
  useEffect(() => {
    const fetchAppointments = async () => {
      if (!user) return
      
      try {
        setLoading(true)
        
        const { data, error } = await supabase
          .from('appointments')
          .select(`
            id,
            user_id,
            date,
            time,
            location,
            status,
            profiles(email),
            packages(name)
          `)
          .eq('status', 'completed')
          .order('date', { ascending: false })
        
        if (error) throw error
        
        if (data) {
          const formattedAppointments = data.map(item => ({
            id: item.id,
            user_id: item.user_id,
            date: item.date,
            time: item.time,
            location: item.location,
            status: item.status,
            user_email: item.profiles?.email || 'Unknown',
            package_name: item.packages?.name || 'Unknown'
          }))
          
          setAppointments(formattedAppointments)
          if (formattedAppointments.length > 0) {
            setSelectedAppointment(formattedAppointments[0].id)
          }
        }
      } catch (error) {
        console.error('Error fetching appointments:', error)
        toast.error('Failed to load appointments')
      } finally {
        setLoading(false)
      }
    }
    
    fetchAppointments()
  }, [user])

  // Fetch photos for selected appointment
  useEffect(() => {
    const fetchPhotos = async () => {
      if (!selectedAppointment) return
      
      try {
        setLoading(true)
        
        let query = supabase
          .from('photos')
          .select('*')
          .order('created_at', { ascending: false })
        
        if (filter === 'all' && selectedAppointment !== 'all') {
          query = query.eq('appointment_id', selectedAppointment)
        } else if (filter === 'portfolio') {
          query = query.eq('is_portfolio', true)
        } else if (filter === 'client') {
          query = query.eq('is_portfolio', false)
          if (selectedAppointment !== 'all') {
            query = query.eq('appointment_id', selectedAppointment)
          }
        }
        
        const { data, error } = await query
        
        if (error) throw error
        
        if (data) {
          setPhotos(data)
        }
      } catch (error) {
        console.error('Error fetching photos:', error)
        toast.error('Failed to load photos')
      } finally {
        setLoading(false)
      }
    }
    
    fetchPhotos()
  }, [selectedAppointment, filter])

  // Handle file upload
  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (!selectedAppointment || selectedAppointment === 'all') {
      toast.error('Please select a specific appointment')
      return
    }
    
    const appointment = appointments.find(a => a.id === selectedAppointment)
    if (!appointment) {
      toast.error('Invalid appointment')
      return
    }
    
    try {
      setUploading(true)
      
      for (const file of acceptedFiles) {
        // Create a unique file name
        const fileExt = file.name.split('.').pop()
        const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`
        const filePath = `photos/${fileName}`
        
        // Upload the file to Supabase Storage
        const { error: uploadError } = await supabase.storage
          .from('photos')
          .upload(filePath, file)
        
        if (uploadError) throw uploadError
        
        // Get the public URL
        const { data: urlData } = supabase.storage
          .from('photos')
          .getPublicUrl(filePath)
        
        if (!urlData || !urlData.publicUrl) {
          throw new Error('Failed to get public URL')
        }
        
        // Create a thumbnail version (in a real app, you'd resize the image)
        const thumbnailUrl = urlData.publicUrl
        
        // Insert the photo record
        const { error: insertError } = await supabase
          .from('photos')
          .insert({
            user_id: appointment.user_id,
            appointment_id: selectedAppointment,
            url: urlData.publicUrl,
            thumbnail_url: thumbnailUrl,
            title: uploadData.title || file.name,
            description: uploadData.description || 'Photo from your session',
            is_portfolio: uploadData.is_portfolio
          })
        
        if (insertError) throw insertError
      }
      
      toast.success('Photos uploaded successfully')
      
      // Reset form and refresh photos
      setUploadData({
        title: '',
        description: '',
        is_portfolio: false
      })
      
      // Refresh the photos list
      const { data, error } = await supabase
        .from('photos')
        .select('*')
        .eq('appointment_id', selectedAppointment)
        .order('created_at', { ascending: false })
      
      if (error) throw error
      
      if (data) {
        setPhotos(data)
      }
    } catch (error) {
      console.error('Error uploading photos:', error)
      toast.error('Failed to upload photos')
    } finally {
      setUploading(false)
    }
  }, [selectedAppointment, appointments, uploadData])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif']
    }
  })

  // Handle appointment change
  const handleAppointmentChange = (appointmentId: string) => {
    setSelectedAppointment(appointmentId)
  }

  // Handle filter change
  const handleFilterChange = (newFilter: string) => {
    setFilter(newFilter)
  }

  // Start editing a photo
  const handleEditPhoto = (photo: Photo) => {
    setEditingPhoto(photo.id)
    setEditData({
      title: photo.title,
      description: photo.description,
      is_portfolio: photo.is_portfolio
    })
  }

  // Save edited photo
  const handleSaveEdit = async (photoId: string) => {
    try {
      const { error } = await supabase
        .from('photos')
        .update({
          title: editData.title,
          description: editData.description,
          is_portfolio: editData.is_portfolio
        })
        .eq('id', photoId)
      
      if (error) throw error
      
      // Update local state
      setPhotos(photos.map(photo => 
        photo.id === photoId 
          ? { ...photo, ...editData }
          : photo
      ))
      
      setEditingPhoto(null)
      toast.success('Photo updated successfully')
    } catch (error) {
      console.error('Error updating photo:', error)
      toast.error('Failed to update photo')
    }
  }

  // Delete a photo
  const handleDeletePhoto = async (photoId: string) => {
    if (!confirm('Are you sure you want to delete this photo? This action cannot be undone.')) {
      return
    }
    
    try {
      const { error } = await supabase
        .from('photos')
        .delete()
        .eq('id', photoId)
      
      if (error) throw error
      
      // Update local state
      setPhotos(photos.filter(photo => photo.id !== photoId))
      toast.success('Photo deleted successfully')
    } catch (error) {
      console.error('Error deleting photo:', error)
      toast.error('Failed to delete photo')
    }
  }

  // Format date
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }

  if (loading && appointments.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Photo Management</h1>
        <p className="mt-1 text-gray-500">
          Upload, organize, and manage photos for your clients and portfolio.
        </p>
      </div>
      
      {/* Filters and controls */}
      <div className="bg-white shadow rounded-lg mb-8">
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-6">
            <div className="md:w-1/2">
              <label htmlFor="appointment" className="block text-sm font-medium text-gray-700 mb-1">
                Select Appointment
              </label>
              <select
                id="appointment"
                value={selectedAppointment || ''}
                onChange={(e) => handleAppointmentChange(e.target.value)}
                className="form-input"
              >
                <option value="all">All Appointments</option>
                {appointments.map((appointment) => (
                  <option key={appointment.id} value={appointment.id}>
                    {appointment.package_name} - {appointment.user_email} - {formatDate(appointment.date)}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="flex space-x-2">
              <button
                onClick={() => handleFilterChange('all')}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  filter === 'all'
                    ? 'bg-primary-100 text-primary-800'
                    : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                }`}
              >
                All Photos
              </button>
              <button
                onClick={() => handleFilterChange('portfolio')}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  filter === 'portfolio'
                    ? 'bg-primary-100 text-primary-800'
                    : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                }`}
              >
                <FolderIcon className="inline-block h-4 w-4 mr-1" />
                Portfolio
              </button>
              <button
                onClick={() => handleFilterChange('client')}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  filter === 'client'
                    ? 'bg-primary-100 text-primary-800'
                    : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                }`}
              >
                <UserIcon className="inline-block h-4 w-4 mr-1" />
                Client Galleries
              </button>
            </div>
          </div>
          
          {/* Upload section */}
          <div 
            {...getRootProps()} 
            className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
              isDragActive ? 'border-primary-500 bg-primary-50' : 'border-gray-300 hover:border-primary-400'
            }`}
          >
            <input {...getInputProps()} />
            <div className="space-y-2">
              <div className="mx-auto h-12 w-12 text-gray-400">
                <ArrowUpTrayIcon className="h-12 w-12" />
              </div>
              <div className="text-sm text-gray-600">
                <p className="font-medium">
                  {isDragActive ? 'Drop the files here' : 'Drag and drop photos here, or click to select files'}
                </p>
                <p className="mt-1">JPG, PNG, GIF up to 10MB each</p>
              </div>
            </div>
          </div>
          
          {/* Upload options */}
          <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Title (for all uploads)
              </label>
              <input
                type="text"
                id="title"
                value={uploadData.title}
                onChange={(e) => setUploadData({ ...uploadData, title: e.target.value })}
                placeholder="e.g., Graduation Photos"
                className="form-input"
              />
            </div>
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Description (for all uploads)
              </label>
              <input
                type="text"
                id="description"
                value={uploadData.description}
                onChange={(e) => setUploadData({ ...uploadData, description: e.target.value })}
                placeholder="e.g., Photos from your graduation session"
                className="form-input"
              />
            </div>
            <div className="flex items-end">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={uploadData.is_portfolio}
                  onChange={(e) => setUploadData({ ...uploadData, is_portfolio: e.target.checked })}
                  className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Add to portfolio</span>
              </label>
            </div>
          </div>
        </div>
      </div>
      
      {/* Photos grid */}
      <div className="bg-white shadow rounded-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-gray-900">
              {filter === 'all' ? 'All Photos' : 
               filter === 'portfolio' ? 'Portfolio Photos' : 'Client Gallery Photos'}
              {photos.length > 0 && ` (${photos.length})`}
            </h2>
            {uploading && (
              <div className="flex items-center text-primary-600">
                <ArrowPathIcon className="animate-spin h-5 w-5 mr-2" />
                <span>Uploading...</span>
              </div>
            )}
          </div>
        </div>
        
        {photos.length === 0 ? (
          <div className="p-12 text-center">
            <PhotoIcon className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No photos</h3>
            <p className="mt-1 text-sm text-gray-500">
              {filter === 'all' ? 
                'No photos have been uploaded for this appointment yet.' : 
                filter === 'portfolio' ? 
                  'No photos have been added to your portfolio yet.' : 
                  'No photos have been added to client galleries yet.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-6">
            {photos.map((photo) => (
              <div key={photo.id} className="bg-white rounded-lg overflow-hidden shadow border border-gray-200">
                <div className="aspect-ratio-portrait">
                  <img
                    src={photo.thumbnail_url || photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                {editingPhoto === photo.id ? (
                  <div className="p-4">
                    <input
                      type="text"
                      value={editData.title}
                      onChange={(e) => setEditData({ ...editData, title: e.target.value })}
                      className="form-input mb-2 text-sm"
                      placeholder="Title"
                    />
                    <input
                      type="text"
                      value={editData.description}
                      onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                      className="form-input mb-2 text-sm"
                      placeholder="Description"
                    />
                    <div className="flex items-center mb-3">
                      <input
                        type="checkbox"
                        checked={editData.is_portfolio}
                        onChange={(e) => setEditData({ ...editData, is_portfolio: e.target.checked })}
                        className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                      />
                      <span className="ml-2 text-sm text-gray-700">Portfolio</span>
                    </div>
                    <div className="flex justify-end space-x-2">
                      <button
                        onClick={() => setEditingPhoto(null)}
                        className="p-1 rounded-md text-gray-400 hover:text-gray-500"
                      >
                        <XMarkIcon className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleSaveEdit(photo.id)}
                        className="p-1 rounded-md text-primary-600 hover:text-primary-700"
                      >
                        <CheckIcon className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-medium text-gray-900 truncate">{photo.title}</h3>
                      {photo.is_portfolio && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-primary-100 text-primary-800">
                          Portfolio
                        </span>
                      )}
                    </div>
                    <p className="text-gray-500 text-sm truncate mb-3">{photo.description}</p>
                    <div className="flex justify-end space-x-2">
                      <button
                        onClick={() => handleEditPhoto(photo)}
                        className="p-1 rounded-md text-gray-400 hover:text-gray-500"
                      >
                        <PencilIcon className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleDeletePhoto(photo.id)}
                        className="p-1 rounded-md text-red-400 hover:text-red-500"
                      >
                        <TrashIcon className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default PhotoManagementPage
