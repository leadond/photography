import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import GalleryGrid from '../components/GalleryGrid'
import CategoryFilter from '../components/CategoryFilter'

interface Photo {
  id: string
  url: string
  title: string
  category: string
}

const GalleryPage = () => {
  const [activeCategory, setActiveCategory] = useState<string | undefined>(undefined)
  const [categories, setCategories] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Sample photos data - in a real app, this would come from your database
  const photos: Photo[] = [
    {
      id: '1',
      url: 'https://images.pexels.com/photos/1024993/pexels-photo-1024993.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Graduation Day',
      category: 'Graduation'
    },
    {
      id: '2',
      url: 'https://images.pexels.com/photos/1157557/pexels-photo-1157557.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Family Portrait',
      category: 'Family'
    },
    {
      id: '3',
      url: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Corporate Meeting',
      category: 'Corporate'
    },
    {
      id: '4',
      url: 'https://images.pexels.com/photos/1586996/pexels-photo-1586996.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Professional Headshot',
      category: 'Headshots'
    },
    {
      id: '5',
      url: 'https://images.pexels.com/photos/267885/pexels-photo-267885.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'University Graduation',
      category: 'Graduation'
    },
    {
      id: '6',
      url: 'https://images.pexels.com/photos/1128318/pexels-photo-1128318.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Family at Beach',
      category: 'Family'
    },
    {
      id: '7',
      url: 'https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Corporate Team Building',
      category: 'Corporate'
    },
    {
      id: '8',
      url: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Professional Portrait',
      category: 'Headshots'
    },
    {
      id: '9',
      url: 'https://images.pexels.com/photos/1205033/pexels-photo-1205033.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Graduation Ceremony',
      category: 'Graduation'
    },
    {
      id: '10',
      url: 'https://images.pexels.com/photos/1231365/pexels-photo-1231365.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Family Gathering',
      category: 'Family'
    },
    {
      id: '11',
      url: 'https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Corporate Event',
      category: 'Corporate'
    },
    {
      id: '12',
      url: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Studio Headshot',
      category: 'Headshots'
    },
    {
      id: '13',
      url: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Business Meeting',
      category: 'Corporate'
    },
    {
      id: '14',
      url: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Team Collaboration',
      category: 'Corporate'
    },
    {
      id: '15',
      url: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      title: 'Creative Headshot',
      category: 'Headshots'
    }
  ]

  useEffect(() => {
    // Extract unique categories from photos
    const uniqueCategories = Array.from(new Set(photos.map(photo => photo.category)))
    setCategories(uniqueCategories)
    
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 800)
    
    return () => clearTimeout(timer)
  }, [])

  const handleCategoryChange = (category: string | undefined) => {
    setActiveCategory(category)
  }

  return (
    <div className="bg-white">
      {/* Hero section */}
      <div className="relative bg-dark-800 h-[40vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 overflow-hidden opacity-40">
          <img 
            src="https://images.pexels.com/photos/1666021/pexels-photo-1666021.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
            alt="Gallery background" 
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-dark-800/60"></div>
        </div>
        
        {/* Film strip decoration */}
        <div className="absolute top-0 w-full h-8 bg-dark-900 flex justify-between px-4">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="w-3 h-3 bg-dark-700 rounded-full my-2.5"></div>
          ))}
        </div>
        <div className="absolute bottom-0 w-full h-8 bg-dark-900 flex justify-between px-4">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="w-3 h-3 bg-dark-700 rounded-full my-2.5"></div>
          ))}
        </div>
        
        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white font-display"
          >
            Our Gallery
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-4 text-xl text-gray-300 max-w-3xl mx-auto"
          >
            Browse through our portfolio of professional photography work
          </motion.p>
        </div>
      </div>
      
      {/* Gallery content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Category filter */}
        <CategoryFilter 
          categories={categories} 
          activeCategory={activeCategory} 
          onCategoryChange={handleCategoryChange} 
        />
        
        {/* Loading state */}
        {isLoading ? (
          <div className="flex justify-center items-center h-96">
            <div className="camera-shutter animate-pulse-slow"></div>
          </div>
        ) : (
          <GalleryGrid photos={photos} category={activeCategory} />
        )}
      </div>
    </div>
  )
}

export default GalleryPage
