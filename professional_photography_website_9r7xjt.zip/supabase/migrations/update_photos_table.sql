/*
  # Update photos table for portfolio categorization

  1. Changes
    - Add `is_portfolio` boolean column to photos table
    - Default value is false (client photos)
    - This allows photos to be categorized as portfolio or client photos
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add is_portfolio column to photos table
ALTER TABLE photos ADD COLUMN IF NOT EXISTS is_portfolio BOOLEAN DEFAULT false;